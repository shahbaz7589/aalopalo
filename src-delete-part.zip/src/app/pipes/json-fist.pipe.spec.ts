import { JsonFistPipe } from './json-fist.pipe';

describe('JsonFistPipe', () => {
  it('create an instance', () => {
    const pipe = new JsonFistPipe();
    expect(pipe).toBeTruthy();
  });
});
