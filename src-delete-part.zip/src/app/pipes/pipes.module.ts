import { NgModule } from '@angular/core';
import { TimeAgoPipe } from './time-ago.pipe';
import { TranslatePipe } from './translate.pipe';
import { JsonFistPipe } from './json-fist.pipe';

@NgModule({
	declarations: [
		TimeAgoPipe,
		TranslatePipe,
		JsonFistPipe
	],
	imports: [],
	exports: [
		TimeAgoPipe,
		TranslatePipe,
		JsonFistPipe
	]
})
export class PipesModule { }

