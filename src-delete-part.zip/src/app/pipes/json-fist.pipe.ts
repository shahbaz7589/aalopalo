import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'jsonFist'
})
export class JsonFistPipe implements PipeTransform {
  transform(value: any, ...args: any[]): any {
    let item: any[];
    item = value.split(",");
    return item[0];
  }
}