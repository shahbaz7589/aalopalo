import {Platform} from '@ionic/angular';
import {Injectable} from '@angular/core';
import {Storage} from '@ionic/storage';
import {BehaviorSubject, from} from 'rxjs';
import {map, switchMap, take, tap} from 'rxjs/operators';
import {JwtHelperService} from '@auth0/angular-jwt';
import {HttpClient} from '@angular/common/http';
import {Router} from '@angular/router';
import {ConfigService} from './config.service';

const helper = new JwtHelperService();
const TOKEN_KEY = 'jwt-token';

@Injectable({
    providedIn: 'root'
})
export class AuthService {

    public user: any;
    private tokenData = new BehaviorSubject(null);
    authenticationState: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);

    constructor(
        private storage: Storage,
        private http: HttpClient,
        private plt: Platform,
        private router: Router,
        public config: ConfigService
        ) {
        // this.loadStoredToken();
    }

    // loadStoredToken() {
    //     const platformObs = from(this.plt.ready());
    //     this.user = platformObs.pipe(
    //         switchMap(() => {
    //             return from(this.storage.get(TOKEN_KEY));
    //         }),
    //         map(token => {
    //             if (token) {
    //                 console.log(`token present`)
    //                 const decoded = helper.decodeToken(token);
    //                 this.tokenData.next(decoded);
    //                 this.authenticationState.next(true);
    //                 return true;
    //             } else {
    //                 console.log(`token not present`)
    //                 this.authenticationState.next(false);
    //                 return false;
    //             }
    //         })
    //         );
    // }
initService(){
    this.storage.get(TOKEN_KEY).then((tkn) =>{
        // console.log(tkn)
    //   take(1), // Otherwise the Observable doesn't complete!
        if (tkn) {
        this.authenticationState.next(true);
        } else {
        this.authenticationState.next(false);
        }
    }).catch(err =>{
        this.authenticationState.next(false);
    })
    // this.loadStoredToken()
}
    login(credentials: { phone: string, password: string }) {
        return this.http.post(this.config.serverUrl + 'applogin', credentials).pipe(
            take(1),
            map((res: any) => {
                return res
            }),
            tap(token => {
                this.storage.set('token', token).then(() => {
                    console.log('Token Stored');
                },
                error => console.error('Error storing item', error)
                );
                return token;
            }),
            switchMap(res => {
                console.log(JSON.stringify(res))
                const decoded = helper.decodeToken(res.token);
                this.tokenData.next(decoded);
                this.authenticationState.next(true);
                this.config.status = res.status;
                this.storage.set('userData', res.user).then(() => {
                }, error => console.error('Error storing item', error));
                return from(this.storage.set(TOKEN_KEY, res.token));
            })
            );
    }

    refreshUser() {
        return this.http.post(this.config.serverUrl + 'getUserById', {id: this.user.id}).pipe(
            take(1),
            map((res: any) => {
                return res
            }),
            switchMap(res => {
                this.storage.set('userData', res.user);
                return from(this.storage.set(TOKEN_KEY, res.token));
            })
            );
    }

    getTokenData() {
        return this.tokenData.getValue();
    }

    getUser() {
        if (this.storage.get('userData')) {
            console.log("GET USER ---------------------> ",this.storage.get('userData'));
            return this.storage.get('userData');
        } else {
            console.log(`getuser else`)
            this.router.navigateByUrl('/login').then();
        }
    }

    logout() {
        this.storage.remove('userData');
        this.storage.remove('token');
        this.storage.remove(TOKEN_KEY).then(() => {
            this.tokenData.next(null);
            this.authenticationState.next(false);
            this.router.navigateByUrl('/');
        });
    }

    get windowRef() {
        return window
    }

    isAuthenticated() {
        return this.authenticationState.value;
    }
}