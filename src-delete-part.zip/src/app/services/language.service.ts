import { Injectable, Inject } from '@angular/core';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { Storage } from '@ionic/storage';
import { Platform } from '@ionic/angular';
import {DOCUMENT} from '@angular/common';
import { ConfigService } from './config.service';

const LNG_KEY = 'SELECTED_LANGUAGE';
type ReadingDirection = 'ltr' | 'rtl';

@Injectable({
  providedIn: 'root'
})
export class LanguageService {

  selected = '';

  constructor(
    @Inject(DOCUMENT) private doc,
    private translate: TranslateService,
    private storage: Storage,
    public platform: Platform,
    public config: ConfigService
  ) { }

  public setReadingDirection(dir: ReadingDirection) {
    this.doc.dir = dir;
    this.config.dir = dir;
  }

  public getDirection() {
    return this.doc.dir;
  }

  setInitialAppLanguage() {
    const language = this.translate.getBrowserLang();
    this.translate.setDefaultLang(language);

    this.storage.get(LNG_KEY).then(val => {
      if (val) {
        this.setLanguage(val);
        this.selected = val;
      }
    });

    // this is to determine the text direction depending on the selected language
    this.translate.onLangChange.subscribe((event: LangChangeEvent) => {
      if (event.lang === 'ar') {
        this.setReadingDirection('rtl');
      } else {
        this.setReadingDirection('ltr');
      }
    });
  }

  setLanguage(lng: any) {
    this.translate.use(lng);
    this.selected = lng;
    this.storage.set(LNG_KEY, lng);
  }

  getLanguage() {
    return [
      { text: 'English', value: 'en', img: 'assets/img/langs/en.png' },
      { text: 'German', value: 'ge', img: 'assets/img/langs/ge.png' },
      { text: 'French', value: 'fr', img: 'assets/img/langs/fr.png' },
      { text: 'Spanish', value: 'es', img: 'assets/img/langs/es.png' },
      { text: 'Arabic', value: 'ar', img: 'assets/img/langs/ar.png' },
    ];
  }


}
