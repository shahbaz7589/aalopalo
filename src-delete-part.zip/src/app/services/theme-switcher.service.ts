import {Injectable, Inject} from '@angular/core';
import {DOCUMENT} from '@angular/common';
import {DomController} from '@ionic/angular';
import {Storage} from '@ionic/storage';

const THEME_KEY = 'SELECTED_THEME';

interface Theme {
    name: string;
    styles: ThemeStyle[];
}

interface ThemeStyle {
    themeVariable: string;
    value: string;
}

@Injectable({
    providedIn: 'root'
})
export class ThemeSwitcherService {

    private themes: Theme[] = [];
    private currentTheme = 0;
    selected = '';

    constructor(
        private domCtrl: DomController,
        @Inject(DOCUMENT) private document,
        private storage: Storage,
    ) {

        this.themes = [
            {
                name: 'default',
                styles: [
                    {themeVariable: '--ion-color-primary', value: '#ff5722'},
                    {themeVariable: '--ion-color-primary-rgb', value: '255,87,34'},
                    {themeVariable: '--ion-color-primary-contrast', value: '#ffffff'},
                    {themeVariable: '--ion-color-primary-contrast-rgb', value: '0,0,0'},
                    {themeVariable: '--ion-color-primary-shade', value: '#e04d1e'},
                    {themeVariable: '--ion-color-primary-tint', value: '#ff6838'},
                    {themeVariable: '--ion-color-secondary', value: '#607d8b'},
                    {themeVariable: '--ion-color-secondary-rgb', value: '96,125,139'},
                    {themeVariable: '--ion-color-secondary-contrast', value: '#ffffff'},
                    {themeVariable: '--ion-color-secondary-contrast-rgb', value: '255,255,255'},
                    {themeVariable: '--ion-color-secondary-shade', value: '#546e7a'},
                    {themeVariable: '--ion-color-secondary-tint', value: '#708a97'},
                    {themeVariable: '--ion-color-tertiary', value: '#a30000'},
                    {themeVariable: '--ion-color-tertiary-rgb', value: '163,0,0'},
                    {themeVariable: '--ion-color-tertiary-contrast', value: '#ffffff'},
                    {themeVariable: '--ion-color-tertiary-contrast-rgb', value: '255,255,255'},
                    {themeVariable: '--ion-color-tertiary-shade', value: '#8f0000'},
                    {themeVariable: '--ion-color-tertiary-tint', value: '#ac1a1a'},
                ]
            },
            {
                name: 'blue',
                styles: [
                    {themeVariable: '--ion-color-primary', value: '#3880ff'},
                    {themeVariable: '--ion-color-primary-rgb', value: '56, 128, 255'},
                    {themeVariable: '--ion-color-primary-contrast', value: '#ffffff'},
                    {themeVariable: '--ion-color-primary-contrast-rgb', value: '255, 255, 255'},
                    {themeVariable: '--ion-color-primary-shade', value: '#3171e0'},
                    {themeVariable: '--ion-color-primary-tint', value: '#4c8dff'},
                    {themeVariable: '--ion-color-secondary', value: '#3dc2ff'},
                    {themeVariable: '--ion-color-secondary-rgb', value: '61, 194, 255'},
                    {themeVariable: '--ion-color-secondary-contrast', value: '#ffffff'},
                    {themeVariable: '--ion-color-secondary-contrast-rgb', value: '255, 255, 255'},
                    {themeVariable: '--ion-color-secondary-shade', value: '#36abe0'},
                    {themeVariable: '--ion-color-secondary-tint', value: '#50c8ff'},
                    {themeVariable: '--ion-color-tertiary', value: '#5260ff'},
                    {themeVariable: '--ion-color-tertiary-rgb', value: '82, 96, 255'},
                    {themeVariable: '--ion-color-tertiary-contrast', value: '#ffffff'},
                    {themeVariable: '--ion-color-tertiary-contrast-rgb', value: '255, 255, 255'},
                    {themeVariable: '--ion-color-tertiary-shade', value: '#4854e0'},
                    {themeVariable: '--ion-color-tertiary-tint', value: '#6370ff'}
                ]
            }
        ]
    }

    setInitAppTheme() {
        this.storage.get(THEME_KEY).then(val => {
            if (val) {
                this.setTheme(val);
                this.selected = val;
            } else {
                this.setTheme('default');
                this.selected = 'default';
            }
        });
    }

    cycleTheme(): void {
        if (this.themes.length > this.currentTheme + 1) {
            this.currentTheme++;
        } else {
            this.currentTheme = 0;
        }
        this.setTheme(this.themes[this.currentTheme].name);
    }

    setTheme(name): void {
        const theme = this.themes.find(theme => theme.name === name);
        this.selected = name;
        this.storage.set(THEME_KEY, name).then();
        this.domCtrl.write(() => {
            theme.styles.forEach(style => {
                document.documentElement.style.setProperty(style.themeVariable, style.value);
            });
        });
    }

    getTheme() {
        return [
            {name: 'default', color: '#ff5722'},
            {name: 'blue', color: '#3880ff'}
        ]
    }


}
