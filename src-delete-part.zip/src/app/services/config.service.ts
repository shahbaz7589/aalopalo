import {Injectable} from '@angular/core';
import {User} from '../models/user';

@Injectable({
    providedIn: 'root'
})

export class ConfigService {
    // public serverUrl = 'https://sahamasala.com/aalopalo/public/';
    public serverUrl = 'https://aalopalo.com/appadmin/public/';
    public currency = 'Rs.';
    public currencyPos = 'left';
    public address;
    public fbId;
    public email;
    public latitude;
    public longitude;
    public phoneNo;
    public homePage = 1;
    public categoryPage = 1;
    public appName = '';
    public dir = 'ltr';
    public setting: any;
    public slidBanner: any;
    public PartnerBanner: any;
    public userConnect: User;
    public status: {
        active: any,
        inactive: any,
        sold: any,
        expired: any;
    };

    constructor() {
    }

    public siteSetting() {
    }
}
