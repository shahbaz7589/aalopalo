import {Injectable} from '@angular/core';
import {LoadingController} from '@ionic/angular';

@Injectable({
    providedIn: 'root'
})
export class LoadingService {

    loading;

    constructor(
        public loadingCtrl: LoadingController
    ) {
    }

    async show() {
        this.loading = await this.loadingCtrl.create({
            // message: 'Please wait...',
            // duration: 10000,
            spinner: 'bubbles',
            backdropDismiss: true
        });
        await this.loading.present();
    }

    async hide() {
        try {
            await this.loading.dismiss();
        } catch (error) {
        }
    }

    autoHide(time) {
        this.loading = this.loadingCtrl.create({
            duration: time
        });
        this.loading.present().then();
    }

}
