import { Injectable } from '@angular/core';
import { AlertController } from '@ionic/angular';

@Injectable({
  providedIn: 'root'
})
export class AlertService {
  okText = 'ok';
  alertText = 'Alert';
  constructor(
    public alertController: AlertController,
    ) {
  }

  async showWithTitle(title,text) {
    const alert = await this.alertController.create({
      header: title,
      subHeader: text,
      buttons: [this.okText]
    });
    await alert.present();
  }


  async showNotificationAlert(content){
   const alert = await this.alertController.create({
     header:'New Notification',
     cssClass: 'my-custom-class',
     message: content,
     backdropDismiss: false,
     buttons: [       
     'OK',                 
     ]
   });
   await alert.present();
   const { role } = await alert.onDidDismiss();
 }


 async show(text) {
  const alert = await this.alertController.create({
    header: this.alertText,
    subHeader: text,
    buttons: [this.okText]
  });
  await alert.present();
}
}
