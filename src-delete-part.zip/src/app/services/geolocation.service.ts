import {Injectable} from '@angular/core';
import {Geolocation} from '@ionic-native/geolocation/ngx';
import {NativeGeocoder, NativeGeocoderOptions, NativeGeocoderResult} from '@ionic-native/native-geocoder/ngx';

@Injectable({
    providedIn: 'root'
})
export class GeolocationService {
    localisation: {
        latitude: number;
        longitude: number;
        accuracy: number;
        address: string
    };

    constructor(
        private geolocation: Geolocation,
        private nativeGeoCoder: NativeGeocoder,
    ) {
    }

    // GeoEncoder configuration
    geoEncoderOptions: NativeGeocoderOptions = {
        useLocale: true,
        maxResults: 5
    };

    // Get current coordinates of device
    initGeolocation() {
        return new Promise(resolve => {
            this.geolocation.getCurrentPosition().then((data) => {
                this.localisation = {
                    latitude: data.coords.latitude,
                    longitude: data.coords.longitude,
                    accuracy: data.coords.accuracy,
                    address: this.getGeoEncoder(data.coords.latitude, data.coords.longitude)
                };
                console.log(this.localisation.latitude);
                resolve(this.localisation);
            });
        });
    }

    // geoCoder method to fetch address from coordinates passed as arguments
    getGeoEncoder(latitude, longitude) {
        this.nativeGeoCoder.reverseGeocode(latitude, longitude, this.geoEncoderOptions)
            .then((result: NativeGeocoderResult[]) => {
                return this.generateAddress(result[0]);
            })
            .catch((error: any) => {
                alert('Error getting location' + JSON.stringify(error));
            });
        return '';
    }

    // Return Comma separated address
    generateAddress(addressObj) {
        const obj = [];
        let address = '';
        for(const key in addressObj) {
            obj.push(addressObj[key]);
            console.log(addressObj[key]);
        }
        obj.reverse();
        for (const val in obj) {
            if (obj[val].length)
                address += obj[val] + ', ';
        }
        return address.slice(0, -2);
    }

}

interface GeoLoc {
    latitude: number;
    longitude: number;
    accuracy: number;
    address: string
}
