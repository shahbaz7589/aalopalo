import { Router } from '@angular/router';
// import { AngularFireAuth } from '@angular/fire/auth';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { first } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Platform } from '@ionic/angular';
import { ConfigService } from './config.service';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {
  public user: any;

  isAuthenticated: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);
  constructor(private router:Router,
    private storage: Storage,
        private http: HttpClient,
        private plt: Platform,
        public config: ConfigService) { 
    this.checkUser()

  }
isLoggedIn() {
    return this.http.post(this.config.serverUrl + 'getUserById', {id: this.user.id}).pipe().toPromise();
  }
  async checkUser() {
    const user = await this.isLoggedIn()
    if (user) {
     this.isAuthenticated.next(true)
    } else {
      this.isAuthenticated.next(false)
    }
  }

}
