import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/timeout';
import {ConfigService} from './config.service';
import {Storage} from '@ionic/storage';

@Injectable({
    providedIn: 'root'
})
export class AccessDataService {
    server: string;
    public categories = [];
    public locations = [];
    public categoriesWithProduct = [];
    // public setting: any;
    public getProductFeatured: any;
    public getProductMostView: any;
    public PartnerBanner: any;
    public getLatestAd = [];
    public getSponsorAd = [];

    constructor(
        private http: HttpClient,
        public config: ConfigService,
        // public loading: LoadingService,
        public storage: Storage
        ) {

        this.server = this.config.serverUrl;
        this.postData('', 'getAllCategoryWithProducts').subscribe((res: any) => {
            this.categoriesWithProduct = res;
        });
        this.postData('', 'product/getProductFeatured').subscribe((res: any) => {
            this.getProductFeatured = res;
        });
        this.postData('', 'product/getProductMostView').subscribe((res: any) => {
            this.getProductMostView = res;
        });
        this.postData('', 'getSetting').subscribe((res: any) => {
            this.config.setting = res.setting;
        });
        this.postData('', 'getSlidBanner').subscribe((res: any) => {
            this.config.slidBanner = res.sliders;
        });
        this.postData('', 'getPartner').subscribe((res: any) => {
            console.log(res);
            this.PartnerBanner = res.partners;
        });
    }

    async getCategory() {
        return new Promise(resolve => {
            const body = {};
            this.postData(body, 'getCategories').subscribe((res: any) => {
                for (const data of res) {
                    this.categories.push(data);
                }
                resolve(this.categories);
            });
        });
    }

    async getLocation() {
        return new Promise(resolve => {
            const body = {};
            this.postData(body, 'getLocations').subscribe((res: any) => {
                if (res.locations) {
                    this.locations = res.locations;
                    resolve(this.locations);
                }
            });
        });
    }

    postData(body, file) {
        const header = new HttpHeaders({
            'Content-Type': 'application/json; charset=UTF-8'
        });
        const options = {
            headers: header
        };

        return this.http.post(this.config.serverUrl + file, JSON.stringify(body), options)
            .timeout(59000) // 59 sec timeout
            .map(res => res);
        }


        isNullOrUndefined(data:any){
            if(data ==null && data == undefined){
              return true;
          }else {
              return false;
          }
      }
  }