import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { ThemeSwitcherService } from 'src/app/services/theme-switcher.service';

@Component({
  selector: 'app-themes',
  templateUrl: './themes.page.html',
  styleUrls: ['./themes.page.scss'],
})
export class ThemesPage implements OnInit {

  themes = [];
  selected = '';
  constructor(
    private modalController: ModalController,
    public themeService: ThemeSwitcherService
  ) { }

  ngOnInit() {
    this.themes = this.themeService.getTheme();
    this.selected = this.themeService.selected;
  }

  async select(theme) {
    this.themeService.setTheme(theme);
    await this.modalController.dismiss();
  }

  async closeModal() {
    await this.modalController.dismiss();
  }

}
