import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NavParams, ModalController, IonSlides } from '@ionic/angular';
import { AccessDataService } from 'src/app/services/access-data.service';

@Component({
  selector: 'app-image-modal',
  templateUrl: './image-modal.page.html',
  styleUrls: ['./image-modal.page.scss'],
})
export class ImageModalPage implements OnInit {

  img: any;
  @ViewChild('slider', {static: false, read: ElementRef}) slider: ElementRef;
  // @ViewChild('slider') protected slides: IonSlides;

  sliderOpts = {
    zoom: {
      maxRatio: 5,
    }
  };

  constructor(
    private navParams: NavParams,
    private modalController: ModalController,
    public accessData: AccessDataService
  ) { }

  ngOnInit() {
    this.img = this.navParams.get('img');
  }

  zoom(zoomIn: boolean){
    const swiper = this;
    const zoom = this.slider.nativeElement.swiper.zoom;
    if(zoomIn) {
      zoom.in();
    } else {
      zoom.out();
    }
  }

  close(){
    this.modalController.dismiss();
  }

}
