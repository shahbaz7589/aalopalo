import { Component, OnInit } from '@angular/core';
import { ModalController, NavParams } from '@ionic/angular';
import { LanguageService } from 'src/app/services/language.service';

@Component({
  selector: 'app-language',
  templateUrl: './language.page.html',
  styleUrls: ['./language.page.scss'],
})
export class LanguagePage implements OnInit {

  languages = [];
  selected = '';

  constructor(
    private modalController: ModalController,
    public languageService: LanguageService
  ) {}

  ngOnInit() {
    this.languages = this.languageService.getLanguage();
    this.selected = this.languageService.selected;
  }

  async select(lng) {
    this.languageService.setLanguage(lng);
    await this.modalController.dismiss(lng);
  }

  async closeModal() {
    await this.modalController.dismiss();
  }

}
