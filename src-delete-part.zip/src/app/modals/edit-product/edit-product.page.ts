import {Component, OnInit} from '@angular/core';
import {ModalController, NavParams, ToastController} from '@ionic/angular';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {Product} from '../../models/product';
import {LoadingService} from '../../services/loading.service';
import {AccessDataService} from '../../services/access-data.service';
import {AlertService} from '../../services/alert.service';

@Component({
    selector: 'app-edit-product',
    templateUrl: './edit-product.page.html',
    styleUrls: ['./edit-product.page.scss'],
})
export class EditProductPage implements OnInit {

    onForm: FormGroup;
    itemData: any = Product;
    isSubmitted = false;
    adTypes: any[] = [
        {
            id: 1,
            name: 'Buy',
        },
        {
            id: 2,
            name: 'Exchange',
        },
        {
            id: 3,
            name: 'Lost and Found',
        },
        {
            id: 4,
            name: 'Sell',
        }
    ];
    status: any[] = [
        {
            id: 1,
            name: 'Active',
        },
        {
            id: 2,
            name: 'Sold',
        },
        {
            id: 3,
            name: 'Inactive',
        }
    ];
    constructor(
        private modalController: ModalController,
        private formBuilder: FormBuilder,
        private navParams: NavParams,
        public toastController: ToastController,
        public loader: LoadingService,
        public accessData: AccessDataService,
        private alertService: AlertService,
    ) {
        console.log(navParams.data.product);
        if (this.navParams.data.product) {
            this.itemData = navParams.data.product;
        }
    }

    async closeModal() {
        await this.modalController.dismiss('');
    }

    ngOnInit() {
        this.onForm = this.formBuilder.group({
            name: new FormControl(this.itemData.name, [Validators.required, Validators.minLength(2)]),
            price: new FormControl(this.itemData.price),
            address: new FormControl(this.itemData.address),
            description: new FormControl(this.itemData.description),
            ad_type: new FormControl(this.itemData.ad_type),
            status: new FormControl(this.itemData.status),
            condition: new FormControl(this.itemData.condition),
            warranty: new FormControl(this.itemData.warranty),
            user_name: new FormControl(this.itemData.user_name),
            phone_number: new FormControl(this.itemData.phone_number),
        });
    }

    get errorControl() {
        return this.onForm.controls;
    }

    saveData() {
    }

    submitForm() {
        this.isSubmitted = true;
        if (!this.onForm.valid) {
            console.log('Please provide all the required values!');
            return false;
        } else {
            // this.disableButton = true;
            this.loader.show();
            const id = new FormControl(this.itemData.id);
            this.onForm.addControl('id', id);
            console.log(this.onForm.value);

            this.accessData.postData(this.onForm.value, 'products/update').subscribe((res: any) => {
                this.loader.hide();
                if (res.success === true) {
                    this.updateMessage();
                    this.closeModal();
                } else {
                    this.alertService.showWithTitle('Update Failed', 'Wrong credentials.');
                }
            }, (err) => {
                console.log('ERROR: ' + err.message);
            });
        }
    }

    async updateMessage() {
        const toast = await this.toastController.create({
            message: 'Data updates have been successfully completed',
            duration: 2000
        });
        await toast.present();
    }

}
