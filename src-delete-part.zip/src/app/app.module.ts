import { GlobalMethods } from './services/global';
import {NgModule, Injector} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {RouteReuseStrategy} from '@angular/router';
import {IonicModule, IonicRouteStrategy} from '@ionic/angular';
import {SplashScreen} from '@ionic-native/splash-screen/ngx';
import {StatusBar} from '@ionic-native/status-bar/ngx';
import {AppComponent} from './app.component';
import {AppRoutingModule} from './app-routing.module';
import {IonicStorageModule} from '@ionic/storage';
import {HttpClientModule, HttpClient} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import {Crop} from '@ionic-native/crop/ngx';
import {ImagePicker} from '@ionic-native/image-picker/ngx';
import {File} from '@ionic-native/file/ngx';
import {CallNumber} from '@ionic-native/call-number/ngx';
import {Geolocation} from '@ionic-native/geolocation/ngx';
import {NativeGeocoder} from '@ionic-native/native-geocoder/ngx';
import {Device} from '@ionic-native/device/ngx';
import {TranslateModule, TranslateLoader} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import {LanguagePopoverPageModule} from './language-popover/language-popover.module';
import {PipesModule} from './pipes/pipes.module';
import {DataService} from './services/data.service';
import {AccessDataService} from './services/access-data.service';
import {Camera} from '@ionic-native/Camera/ngx';
import {FileTransfer} from '@ionic-native/file-transfer/ngx';
import {WebView} from '@ionic-native/ionic-webview/ngx';
import {FilePath} from '@ionic-native/file-path/ngx';
import {AuthService} from './services/auth.service';
import {LanguageService} from './services/language.service';
import {ConfigService} from './services/config.service';
import {LoadingService} from './services/loading.service';
import {ImageModalPageModule} from './modals/image-modal/image-modal.module';
import {AdmobFreeService} from './services/admob-free.service';
import {AdMobFree} from '@ionic-native/admob-free/ngx';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';
import { Push } from '@ionic-native/push/ngx';

import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';

// Firebase
import { AngularFireModule} from '@angular/fire/compat'
import { AngularFireDatabaseModule } from '@angular/fire/compat/database';
import { environment } from 'src/environments/environment';
import { AngularFireAuthModule } from '@angular/fire/compat/auth';
import { AngularFireStorageModule } from '@angular/fire/compat/storage';


export function createTranslateLoader(http: HttpClient) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
    declarations: [AppComponent],
    entryComponents: [],
    imports: [
    BrowserModule,
    IonicModule.forRoot({
        mode: 'md'
    }),
    FormsModule,
    AppRoutingModule,
    IonicStorageModule.forRoot(),
    AngularFireDatabaseModule,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireAuthModule,
    AngularFireStorageModule,
    HttpClientModule,
    PipesModule,
    TranslateModule.forRoot({
        loader: {
            provide: TranslateLoader,
            useFactory: (createTranslateLoader),
            deps: [HttpClient]
        }
    }),
    LanguagePopoverPageModule,
    ImageModalPageModule,
    ],
    providers: [
    StatusBar,
    SplashScreen,
    Crop,
    File,
    Device,
    Camera,
    WebView,
    FilePath,
    CallNumber,
    ImagePicker,
    GlobalMethods,
    DataService,
    SocialSharing,
    Geolocation,
    AndroidPermissions,
    LocationAccuracy,
    FileTransfer,
    NativeGeocoder,
    AccessDataService,
    AuthService,
    LanguageService,
    ConfigService,
    Push,
    LoadingService,
    AdMobFree,
    AdmobFreeService,
    {provide: RouteReuseStrategy, useClass: IonicRouteStrategy}],
    bootstrap: [AppComponent]
})
export class AppModule {
    public static injector: Injector;

    constructor(private injector: Injector) {
        AppModule.injector = injector;
    }

}
