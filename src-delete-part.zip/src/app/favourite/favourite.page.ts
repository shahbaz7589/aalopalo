import { GlobalMethods } from './../services/global';
import {Component, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {NavController} from '@ionic/angular';
import {ConfigService} from 'src/app/services/config.service';
import {AccessDataService} from '../services/access-data.service';
import {AuthService} from '../services/auth.service';
import {User} from '../models/user';
import {LoadingService} from '../services/loading.service';

@Component({
    selector: 'app-favourite',
    templateUrl: './favourite.page.html',
    styleUrls: ['./favourite.page.scss'],
})
export class FavouritePage implements OnInit {

    public products: any[] = [];
    public id: any;
    public user;

    constructor(
        public http: HttpClient,
        public navCtrl: NavController,
        public auth: AuthService,
        public config: ConfigService,
        public accessData: AccessDataService,
        private loader: LoadingService,
        public global:GlobalMethods
    ) {
    }

    ngOnInit() {
    }

    ionViewDidEnter() {
        this.auth.getUser().then(user => {
            this.user = new User(user);
            console.log(this.user);
            this.getFavouriteProduct(user.id);
        });
    }

    async getFavouriteProduct(id: any) {
        await this.loader.show();
        return new Promise(resolve => {
            const body = {
                user_id: this.user.id
            };
            this.accessData.postData(body, 'products/getMyFavourite').subscribe((res: any) => {
                this.loader.hide();
                this.products = [];
                res.user.favourites.forEach(favourite => {
                    this.products.push(favourite.product);
                });
                resolve(true);
            });
        });
    }

    async doRefresh(event) {
        this.ionViewDidEnter();
        event.target.complete();
    }
}
