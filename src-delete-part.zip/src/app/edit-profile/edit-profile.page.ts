import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ActionSheetController, NavController, Platform, ToastController} from '@ionic/angular';
import {AccessDataService} from 'src/app/services/access-data.service';
import {AlertService} from 'src/app/services/alert.service';
import {Storage} from '@ionic/storage';

import {Camera, CameraOptions, PictureSourceType} from '@ionic-native/Camera/ngx';
import {File} from '@ionic-native/file/ngx';
import {WebView} from '@ionic-native/ionic-webview/ngx';
import {LoadingService} from 'src/app/services/loading.service';

import {Crop} from '@ionic-native/crop/ngx';
import {FileTransfer, FileTransferObject, FileUploadOptions} from '@ionic-native/file-transfer/ngx';
import {FilePath} from '@ionic-native/file-path/ngx';
import {ConfigService} from 'src/app/services/config.service';
import {AuthService} from '../services/auth.service';
import {User} from '../models/user';

@Component({
    selector: 'app-edit-profile',
    templateUrl: './edit-profile.page.html',
    styleUrls: ['./edit-profile.page.scss'],
})
export class EditProfilePage implements OnInit {
    id: number;
    name = '';
    email = '';
    phone = '';
    presentation = '';
    location = '';
    facebook = '';
    googlePlus = '';
    twitter = '';

    profilePhoto = '../../../assets/avatar-han.jpg';

    disableButton;

    // For Photo profile

    isLoading = false;

    imagePickerOptions = {
        maximumImagesCount: 1,
        quality: 50
    };


    error;

    fileUrl: any = null;
    respData: any;


    constructor(
        private router: Router,
        public accessData: AccessDataService,
        private actRoute: ActivatedRoute,
        private alertService: AlertService,
        private storage: Storage,
        private platform: Platform,
        private camera: Camera,
        public actionSheetController: ActionSheetController,
        private file: File,
        private transfer: FileTransfer,
        private webview: WebView,
        private toastController: ToastController,
        public loader: LoadingService,
        private crop: Crop,
        public navCtrl: NavController,
        private filePath: FilePath,
        public config: ConfigService,
        public auth: AuthService
    ) {
    }

    ngOnInit() {
        this.actRoute.params.subscribe((data: any) => {
            console.log(data);
            this.id = data.id;

            if (this.id !== 0) {
                this.loadUser();
            }
        });
    }

    async selectImage() {
        const actionSheet = await this.actionSheetController.create({
            header: 'Select Image source',
            buttons: [{
                text: 'Load from Library',
                handler: () => {
                    this.takePicture(this.camera.PictureSourceType.PHOTOLIBRARY);
                }
            },
                {
                    text: 'Use Camera',
                    handler: () => {
                        this.takePicture(this.camera.PictureSourceType.CAMERA);
                    }
                },
                {
                    text: 'Cancel',
                    role: 'cancel'
                }
            ]
        });
        await actionSheet.present();
    }


    takePicture(sourceType: PictureSourceType) {
        const options: CameraOptions = {
            quality: 100,
            sourceType,
            saveToPhotoAlbum: false,
            correctOrientation: true
        };
        this.camera.getPicture(options).then((imagePath) => {
            if (this.platform.is('android') && sourceType === this.camera.PictureSourceType.PHOTOLIBRARY) {
                this.filePath.resolveNativePath(imagePath)
                    .then(filePath => {
                        const correctPath = filePath.substr(0, filePath.lastIndexOf('/') + 1);
                        const currentName = imagePath.substring(imagePath.lastIndexOf('/') + 1, imagePath.lastIndexOf('?'));
                        this.copyFileToLocalDir(correctPath, currentName, this.createFileName());
                    });
            } else {
                const currentName = imagePath.substr(imagePath.lastIndexOf('/') + 1);
                const correctPath = imagePath.substr(0, imagePath.lastIndexOf('/') + 1);
                this.copyFileToLocalDir(correctPath, currentName, this.createFileName());
            }
        }, () => {
            // Handle error
        });
    }

    copyFileToLocalDir(correctPath, currentName, newFileName) {
        this.file.copyFile(correctPath, currentName, this.file.dataDirectory, newFileName).then(() => {
            const filePath = this.file.dataDirectory + newFileName;
            this.cropImage(filePath, newFileName);
        }, () => {
            this.presentToast('Error while storing file.');
        });
    }

    cropImage(imgPath, fileName) {
        this.crop.crop(imgPath, {quality: 100})
            .then(
                newImage => {
                    this.profilePhoto = newImage;
                    this.uploadImage(fileName);
                },
                error => console.error('Error cropping image', error)
            );
    }

    async uploadImage(fileName) {
        // Show loading
        await this.loader.show();

        // create file transfer object
        const fileTransfer: FileTransferObject = this.transfer.create();

        // option transfer
        const options: FileUploadOptions = {
            fileKey: 'photo',
            fileName: this.id + '-' + fileName,
            chunkedMode: false,
            httpMethod: 'post',
            mimeType: 'image/jpeg',
            headers: {}
        };

        // file transfer action
        fileTransfer.upload(this.profilePhoto, this.config.serverUrl + 'profile/uploadImage', options)
            .then(() => {
                this.profilePhoto = 'images/profile/' + this.id + '-' + fileName;
                this.auth.refreshUser();
                this.loader.hide();
                this.presentToast('Profile photo has been updated')
            }, () => {
                this.loader.hide();
                this.presentToast('A problem occurred while updating the photo')
            });
    }

    createFileName() {
        const d = new Date(),
            n = d.getTime(),
            newFileName = n + '.jpg';
        return newFileName;
    }

    loadUser() {
        return new Promise(() => {
            const body = {
                id: this.id,
            };
            this.accessData.postData(body, 'user/getUserById').subscribe((res: any) => {
                console.log(res);
                this.name = res.user.name;
                this.email = res.user.email;
                this.phone = res.user.phone;
                this.presentation = res.user.presentation;
                this.location = res.user.location;
                this.facebook = res.user.facebook;
                this.googlePlus = res.user.googlePlus;
                this.twitter = res.user.twitter;
                this.profilePhoto = res.user.photo;
            });
        });
    }

    ionViewDidEnter() {
        this.disableButton = false;
    }

    openSearch() {
    }

    openMessage() {
    }

    pathForImage(img) {
        if (img === null) {
            return '';
        } else {
            return this.webview.convertFileSrc(img);
        }
    }

    openCart() {

    }

    async presentToast(text) {
        const toast = await this.toastController.create({
            message: text,
            position: 'bottom',
            duration: 3000
        });
        await toast.present();
    }

    async tryUpdate() {
        if (this.email === '') {
            console.log('Email address is required');
        } else {
            this.disableButton = true;
            await this.loader.show();

            const credentials = {
                id: this.id,
                name: this.name,
                email: this.email,
                phone: this.phone,
                presentation: this.presentation,
                location: this.location,
                facebook: this.facebook,
                googlePlus: this.googlePlus,
                twitter: this.twitter,
            };

            this.accessData.postData(credentials, 'user/update').subscribe((res: any) => {
                this.loader.hide();
                if (res.success === true) {
                    this.storage.set('userData', res.user);
                    this.config.userConnect = new User(res.user);
                    this.router.navigateByUrl('/members/profile');
                } else {
                    this.alertService.showWithTitle('Update Failed', 'Wrong credentials.');
                    console.log(res.msg);
                }
            }, (err) => {
                console.log('ERROR: ' + err.message);
            });
        }
    }
}
