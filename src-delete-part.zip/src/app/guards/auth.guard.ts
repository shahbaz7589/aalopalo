import { AuthService } from './../services/auth.service';
// import { AuthServiceService } from './../services/auth-service.service';
import { Injectable } from '@angular/core';
import { CanLoad, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { filter, map, take } from 'rxjs/operators';
 
@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanLoad {
  constructor(private authService: AuthService, private router: Router) { }
 
  canLoad(): Observable<boolean> {    
    return this.authService.authenticationState.pipe(
      filter(val => val !== null), // Filter out initial Behaviour subject value
      take(1), // Otherwise the Observable doesn't complete!
      map(isAuthenticated => {
      // take(1), // Otherwise the Observable doesn't complete!
      if (isAuthenticated) {
        console.log('Found previous token, automatic login'+isAuthenticated);
          // Directly open inside area       
          this.router.navigateByUrl('home', { replaceUrl: true });
        } else {          
          // Simply allow access to the login
          // this.router.navigateByUrl('login', { replaceUrl: true });
        console.log('Could not found previous token, Please login'+isAuthenticated);
          return true;
        }
      })
    );
  }
}