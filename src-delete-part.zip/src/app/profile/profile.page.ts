import { GlobalMethods } from './../services/global';
import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {ConfigService} from 'src/app/services/config.service';
import {AuthService} from '../services/auth.service';
import {User} from '../models/user';
import {AccessDataService} from '../services/access-data.service';

@Component({
    selector: 'app-profile',
    templateUrl: './profile.page.html',
    styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {

    constructor(
        public auth: AuthService,
        private router: Router,
        public config: ConfigService,
        public accessData: AccessDataService,
        public global:GlobalMethods
    ) {
    }

    ngOnInit() {
    }

    ionViewDidEnter() {
        this.auth.getUser().then(user => {
            this.config.userConnect = new User(user);
            this.accessData.postData({user_id: this.config.userConnect.id}, 'getProductStatusByUser').subscribe((res: any) => {
                this.config.status = res.status;
                // this.active = res.active;
                // this.sold = res.sold;
            });
        });
    }

    editProfile() {
        this.router.navigate(['members/edit-profile/' + this.config.userConnect.id]);
    }
}

