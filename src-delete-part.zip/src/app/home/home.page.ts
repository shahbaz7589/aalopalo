import { GlobalMethods } from './../services/global';
import {Component, OnInit,ViewChild} from '@angular/core';      
import {Router, NavigationExtras} from '@angular/router';
import {ToastController, NavController, MenuController,Platform} from '@ionic/angular';
import {Storage} from '@ionic/storage';
import {AccessDataService} from '../services/access-data.service';
import {LanguageService} from '../services/language.service';
import {ConfigService} from '../services/config.service';
import {LoadingService} from '../services/loading.service';
import {AuthService} from '../services/auth.service';
import {AlertService} from '../services/alert.service';
import {User} from '../models/user';
import { IonSlides } from '@ionic/angular'; 

import { INotificationPayload } from 'cordova-plugin-fcm-with-dependecy-updated';
import { FCM } from 'cordova-plugin-fcm-with-dependecy-updated/ionic/ngx';


const hasValues = (obj) => Object.values(obj).some(v => v !== null && typeof v !== 'undefined');
@Component({
 selector: 'app-home',
 templateUrl: './home.page.html',
 styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {

 @ViewChild('slideWithNav', { static: false }) slideWithNav: IonSlides;
 @ViewChild('slideWithNav2', { static: false }) slideWithNav2: IonSlides;


 public hasPermission: boolean;
 public token: string;
 public pushPayload: INotificationPayload;


 sliderOne: any;
 sliderTwo: any;

 slideOptsOne = {
  initialSlide: 0,
  slidesPerView: 3,
  spaceBetween: 5,
  autoplay: true
};

slideOptstwo = {
  initialSlide: 0,
  slidesPerView: 3,
  spaceBetween: 20,
  autoplay: true
};

categories: any = [];
listCategories: any = [];
getProductFeatured: any = [];
getProductMostView: any = [];
PartnerBanner: any = [];
getLatestAd = [];
getSponsorAd = [];

start = 0;

offset = 0; 
listmaxcount = 0; 
limit = 10;

type: string;
sliderConfig = {
  slidesPerView: 2.2,
  spaceBetween: 0
};
public isSearchBarOpen = false;

constructor(
  private platform: Platform, private fcm: FCM,
  protected toastCtrl: ToastController,
  protected alertctl: AlertService,
  public accessData: AccessDataService,
  protected storage: Storage,
  protected navCtrl: NavController,
  protected authService: AuthService,
  protected menuCtrl: MenuController,
  protected auth: AuthService,
  public languageService: LanguageService,
  public config: ConfigService,
  private router: Router,
  public loader: LoadingService
  ,public global:GlobalMethods
  ) {
  this.ionViewWillEnter();

  this.platform.ready().then(() => {
    if (this.platform.is('cordova')) {
     this.auth.getUser().then(user => {
      if(user != null){
       this.config.userConnect = new User(user);
       this.setupFCM();
     }
   }) }
   });
}

ngOnInit() {
  this.type = 'category';
  if (typeof this.config.setting === 'undefined' ||  !this.config.setting ) {
   this.accessData.postData('', 'getSetting').subscribe((res: any) => {
    this.config.setting = res.setting;
  });
 }
 if (typeof this.config.slidBanner === 'undefined' || !this.config.slidBanner) {
   this.accessData.postData('', 'getSlidBanner').subscribe((res: any) => {
    this.config.slidBanner = res.sliders;
  });
 }
}

ionViewWillEnter() {
  if (typeof this.config.userConnect === 'undefined' || !this.config.userConnect) {
   this.auth.getUser().then(user => {
    if(user != null){
     this.config.userConnect = new User(user);
   }
 })
 }
 this.menuCtrl.enable(true).then();
}

ionViewDidEnter() {
  this.start = 0;
  this.categories = [];
  if(this.config.userConnect != null){
   this.accessData.postData({ user_id: this.config.userConnect.id }, 'getProductStatusByUser').subscribe((res: any) => {
    this.config.status = res.status;
  });
 }
 this.loadCategory().then();
 this.listCategories = this.accessData.categoriesWithProduct;
 this.getProductFeatured = this.accessData.getProductFeatured;
 this.getProductMostView = this.accessData.getProductMostView;
 this.PartnerBanner = this.accessData.PartnerBanner;
 this.CallgetSponsorAd();
 this.CallLatestAds();
}

async doRefresh(event) {
  this.ngOnInit();
  this.ionViewWillEnter();
  this.ionViewDidEnter();
  event.target.complete();
}

async onSearch(event) {
  const research = {
   name: event.target.value
 };
 const navigationExtras: NavigationExtras = {
   state: {
    research
  }
};
await this.router.navigate(['list'], navigationExtras);
}


showDetail(id) {
  console.log(this.config);
  if(this.config.userConnect){
    this.navCtrl.navigateRoot(['/product-detail/' + id]);
  }else{
   this.router.navigate(['login']);
 }
}


async loadCategory() {
  return new Promise(resolve => {
   const body = {limit: 16};
  //  this.loader.show();
  this.global.presentLoading('').then(() =>{
    this.accessData.postData(body, 'getCategories').subscribe((res: any) => {
      for (const data of res) {
       this.categories.push(data);
     }
     this.global.hideLoading()
     resolve(true);
   });
  })
   
 });
}

async openCategoryList(a) {
  await this.navCtrl.navigateRoot(['/categories/' + a]);
}

logout() {
  this.authService.logout();
}

allCategories() {
  this.navCtrl.navigateRoot(['/all-categories']).then();
}



SlideDidChange(object, slideView) {
  this.checkIfNavDisabled(object, slideView);
}


checkIfNavDisabled(object, slideView) {
  this.checkisBeginning(object, slideView);
  this.checkisEnd(object, slideView);
}

checkisBeginning(object, slideView) {
  slideView.isBeginning().then((istrue) => {
   object.isBeginningSlide = istrue;
 });
}

checkisEnd(object, slideView) {
  slideView.isEnd().then((istrue) => {
   object.isEndSlide = istrue;
 });
}


GotoPage(){
  this.navCtrl.navigateRoot(['/all-sponsads']).then();
}



CallgetSponsorAd(){
  this.accessData.postData({"start":0,"limit":5,}, 'products/getSponsorAd').subscribe((res: any) => {
   console.log("SPNS ADS ============>",res);
   this.getSponsorAd = res.products;
 });
}

CallLatestAds(){ 
  // "user_id":this.config.userConnect.id
  this.accessData.postData({"start":0,"limit":10,}, 'products/getLatestAd').subscribe((res: any) => {
   console.log(res);

   if(this.getLatestAd.length ===0){
     this.getLatestAd.push(res.products);
   }
   this.getLatestAd.forEach(x=>{
    x.forEach(y=>{
      if (x.filter(e => e.id === y.id).length < 0) {
        this.getLatestAd.push(res.products);
      }
    })
  })
 });
}


loadData(event) {
  setTimeout(() => {
   this.offset = this.offset + 10;
   let requestData = {
    // "user_id": this.config.userConnect.id,
    "start":this.offset ,
    "limit":this.limit ,
  }
  this.accessData.postData(requestData, 'products/getLatestAd').subscribe((res: any) => {
    this.listmaxcount=res.total_count
    this.getLatestAd.push(res.products);
  });
  event.target.complete();

  let loopCount=0;
  let allLengths = this.getLatestAd.forEach(function(element){
    loopCount=loopCount+element.length
  });

  if (loopCount === this.listmaxcount){
    this.alertctl.showWithTitle("All list completed.","max count reached");
    event.target.disabled = true;
  }
}, 500);
}



private async setupFCM() {
  console.log('FCM setup started');

  await this.platform.ready();

  if (!this.platform.is('cordova')){
    return;
  }

  console.log('In cordova platform');

  console.log('Subscribing to token updates');
  this.fcm.onTokenRefresh().subscribe((newToken) => {
    this.token = newToken;
    console.log('onTokenRefresh received event with: ', newToken);
  });


  this.fcm.onNotification().subscribe((data: any) =>{
    console.log(data);
    if (data.wasTapped){
      this.checkCustomerListNotify(data);
    }else{
      this.alertctl.showWithTitle(data.title,data.body);
      // this.alertctl.showWithTitle(data.title,data.body);
      this.checkCustomerListNotify(data);
    };
  });


  this.hasPermission = await this.fcm.requestPushPermission();
  console.log('requestPushPermission result: ', this.hasPermission);

  this.token = await this.fcm.getToken();
  console.log('getToken result: ', this.token);

  this.pushPayload = await this.fcm.getInitialPushPayload();
  console.log('getInitialPushPayload result: ', this.pushPayload);

  if(this.pushPayload){
    if(this.pushPayload.wasTapped){
      this.checkCustomerListNotify(this.pushPayload)
    }
  }

  let apuid = await this.config.userConnect.id;
  console.log('USER ID ---->: ', apuid);

  this.StoreToken();
}


StoreToken(){
  console.log("UID ===>",this.config.userConnect.id);
  // let requestData = { "device_id": this.token,"user_id":this.config.userConnect.id};
  let requestData = { "device_id": this.token,"user_id":this.config.userConnect.id};
  this.accessData.postData(requestData, 'user/storeDeviceId').subscribe((res: any) => {
    console.log(res);
  });
}



checkCustomerListNotify(data: any){
  console.log(data);
  if (!this.accessData.isNullOrUndefined(data) && data.customer_notify == "true") {
    this.router.navigateByUrl(data.landing_page);
    // this.router.navigateByUrl('/'+data.landing_page);
        // this.router.navigateByUrl('/'+data.landing_page+'/'+data.page_id);
    // this.router.navigateByUrl("/customer-list");
  }
}

OpenSearch(){
  this.router.navigateByUrl('/form');
}

OpenDetail(params){
  window.open(params);
}

}