import { NgModule } from '@angular/core'; 
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { HomePageRoutingModule } from './home-routing.module';

import { HomePage } from './home.page';
import { PipesModule } from '../pipes/pipes.module';
import { TranslateModule } from '@ngx-translate/core';
import { ComponentModule } from '../components/component/component.module';
import { SwiperModule } from 'swiper/angular';
import { FCM } from 'cordova-plugin-fcm-with-dependecy-updated/ionic/ngx';

@NgModule({
  imports: [
  CommonModule,
  FormsModule,
  SwiperModule,
  IonicModule,
  HomePageRoutingModule,
  ComponentModule,
  PipesModule,
  TranslateModule.forChild()
  ],
  providers: [ FCM ],
  entryComponents: [],
  declarations: [HomePage]
})
export class HomePageModule {}
