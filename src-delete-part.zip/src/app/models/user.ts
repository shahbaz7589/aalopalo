export class User {
    id: BigInteger;
    name: string;
    email: string;
    phone: string;
    password: string;
    location: string;
    photo: string;
    presentation: string;
    facebook: string;
    twitter: string;
    googlePlus: string;
    createdAt: Date;
    updatedAt: Date;

    constructor(user) {
        this.id = user.id || '';
        this.name = user.name || '';
        this.email = user.email || '';
        this.phone = user.phone || '';
        this.password = user.password || '';
        this.location = user.location || '';
        this.photo = user.photo || '';
        this.presentation = user.presentation || '';
        this.facebook = user.facebook || '';
        this.twitter = user.twitter || '';
        this.googlePlus = user.googlePlus || '';
        this.createdAt = new Date(user.created_at);
        this.updatedAt = new Date(user.updated_at);
    }
}
