export class Product {
    id: BigInteger;
    name = '';
    price_type = '';
    price: BigInteger;
    currency = '';
    phone_number = '';
    user_name = '';
    warranty = '';
    tags = '';
    youtube_link = '';
    condition = '';
    ad_type = '';
    address = '';
    latitude: number;
    longitude: number;
    description = '';
    photo = '';
    view: BigInteger;
    featured = '';
    likes = '';
    status = '';
    category_id = '';
    location_id = '';
    user_id = '';
    created_at: Date;
    updated_at: Date;

    constructor(product) {
        this.id = product.id || null;
        this.name = product.name || '';
        this.price_type = product.price_type || '';
        this.price = product.price || '';
        this.currency = product.currency || '';
        this.phone_number = product.phone_number || '';
        this.user_name = product.user_name || '';
        this.warranty = product.warranty || '';
        this.tags = product.tags || '';
        this.youtube_link = product.youtube_link || '';
        this.condition = product.condition || '';
        this.ad_type = product.ad_type || '';
        this.address = product.address || '';
        this.latitude = product.latitude || 0;
        this.longitude = product.longitude || 0;
        this.description = product.description || '';
        this.photo = product.photo || '';
        this.view = product.view || '';
        this.featured = product.featured || '';
        this.likes = product.likes || '';
        this.status = product.status || '';
        this.category_id = product.category_id || '';
        this.location_id = product.location_id || '';
        this.user_id = product.user_id || '';
        this.created_at = new Date(product.created_at);
        this.updated_at = new Date(product.updated_at);
    }
}
