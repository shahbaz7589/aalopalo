import { Component, OnInit } from '@angular/core';
import {AccessDataService} from '../services/access-data.service';
import {LoadingService} from '../services/loading.service';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.page.html',
  styleUrls: ['./about-us.page.scss'],
})
export class AboutUsPage implements OnInit {
  aboutText: string;

  constructor(
      public accessData: AccessDataService,
      public loader: LoadingService
  ) { }

  ionViewDidEnter() {
    this.loader.show();
    this.accessData.postData('', 'setting/getAboutUs').subscribe((res: any) => {
      this.aboutText = res.aboutText;
      this.loader.hide();
    });
  }
  ngOnInit() {
  }

  async doRefresh(event: any) {
    this.ionViewDidEnter();
    event.target.complete();
  }
}
