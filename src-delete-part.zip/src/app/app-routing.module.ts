import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  {
    path: 'members',
    loadChildren: () => import('./members/member-routing.module').then(m => m.MemberRoutingModule),
    // canActivate: [AuthGuard]
  },
  {
    path: 'intro',
    loadChildren: () => import('./intro/intro.module').then( m => m.IntroPageModule),
    // loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
    canLoad: [AuthGuard] // Check if we should show the introduction or forward to inside
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule),
    // canLoad: [AuthGuard] // Check if we should show the introduction or forward to inside

  },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'product-detail/:id',
    loadChildren: () => import('./product-detail/product-detail.module').then( m => m.ProductDetailPageModule),
    data: {
      name: 'product-detail'
    }
  },
  {
    path: 'categories/:id',
    loadChildren: () => import('./categories/categories.module').then( m => m.CategoriesPageModule)
  },
  {
    path: 'about-us',
    loadChildren: () => import('./about-us/about-us.module').then( m => m.AboutUsPageModule)
  },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'form',
    loadChildren: () => import('./search/form/form.module').then( m => m.FormPageModule)
  },
  {
    path: 'list',
    loadChildren: () => import('./search/list/list.module').then( m => m.ListPageModule)
  },
  {
    path: 'language',
    loadChildren: () => import('./modals/language/language.module').then( m => m.LanguagePageModule)
  },
  {
    path: 'themes',
    loadChildren: () => import('./modals/themes/themes.module').then( m => m.ThemesPageModule)
  },
  {
    path: 'all-categories',
    loadChildren: () => import('./all-categories/all-categories.module').then( m => m.AllCategoriesPageModule)
  },
  {
    path: 'edit-product',
    loadChildren: () => import('./modals/edit-product/edit-product.module').then( m => m.EditProductPageModule)
  },
  {
    path: 'login-with-phone-number',
    loadChildren: () => import('./login-with-phone-number/login-with-phone-number.module').then( m => m.LoginWithPhoneNumberPageModule)
  },
  {
    path: 'all-sponsads',
    loadChildren: () => import('./all-sponsads/all-sponsads.module').then( m => m.AllSponsadsPageModule)
  },{
    path: '',
    redirectTo: '/intro',
    pathMatch: 'full'
  }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules, relativeLinkResolution: 'legacy' })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
