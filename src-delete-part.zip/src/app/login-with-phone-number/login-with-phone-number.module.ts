import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LoginWithPhoneNumberPageRoutingModule } from './login-with-phone-number-routing.module';

import { LoginWithPhoneNumberPage } from './login-with-phone-number.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LoginWithPhoneNumberPageRoutingModule
  ],
  declarations: [LoginWithPhoneNumberPage]
})
export class LoginWithPhoneNumberPageModule {}
