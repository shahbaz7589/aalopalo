import { Component, OnInit } from '@angular/core';
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import {AuthService} from '../services/auth.service';
import { AlertController } from '@ionic/angular';

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCDfLMNiH4iaxTiTpfJ3N2Np3C8x0ywLzo",
  authDomain: "vongo-2021.firebaseapp.com",
  databaseURL: "https://vongo-2021-default-rtdb.firebaseio.com",
  projectId: "vongo-2021",
  storageBucket: "vongo-2021.appspot.com",
  messagingSenderId: "224016246397",
  appId: "1:224016246397:web:57a8a69cd2159015347314",
  measurementId: "G-66FMD1M24C"
};
@Component({
  selector: 'app-login-with-phone-number',
  templateUrl: './login-with-phone-number.page.html',
  styleUrls: ['./login-with-phone-number.page.scss'],
})

export class LoginWithPhoneNumberPage implements OnInit {
  windowRef: any;
  public mobileNumber :any;
  constructor(public auth:AuthService,public alertController:AlertController) {  

    this.windowRef = this.auth.windowRef;
    firebase.initializeApp(firebaseConfig);
  }

  ngOnInit(){}
  
    async ionViewDidEnter() {
      this.windowRef.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('sign-in-button', {
        size: "invisible",
      })
    }

    ionViewDidLoad() {
     this.windowRef.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('sign-in-button', {
      size: "invisible",
    })
    }
  

  signinWithPhoneNumber(){
    var self = this;
    //this.mobileNumber = '+977'+this.mobileNumber;
    var number = '+91'+self.mobileNumber;
    const appVerifier = self.windowRef.recaptchaVerifier;
    firebase.auth().signInWithPhoneNumber(number, appVerifier).then((confirmationResult) => {
        //OtpVerification for verify OTP
        self.mobileNumber = '';
        self.OtpVerification(confirmationResult);
    }).catch(function (error) {
      console.error("SMS not sent", error);
    });
  }

  async OtpVerification(confirmationResult) {
    var self = this;
    const alert = await self.alertController.create({
      header: 'Enter OTP',
      backdropDismiss: false,
      inputs: [
        {
          name: 'otp',
          type: 'text',
          placeholder: 'Enter your otp',
        }
      ],
      buttons: [{
        text: 'Enter',
        handler: (res) => {
          confirmationResult.confirm(res.otp).then(function (result) {
            self.showSuccess('verify OTP Successfully');
          }).catch(function (error) {
            self.showSuccess(error);
          });
        }
      }
      ]
    });
    await alert.present();
  }

  async showSuccess(data) {
    const alert = await this.alertController.create({
      header: data,
      buttons: [
        {
          text: 'Ok',
          handler: (res) => {
            alert.dismiss();
          }
        }
      ]
    });
    alert.present();
  }
}
