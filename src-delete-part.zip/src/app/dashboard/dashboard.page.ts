import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccessDataService } from '../services/access-data.service';
import { ConfigService } from '../services/config.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
})
export class DashboardPage implements OnInit {

  constructor(
    private router: Router,
    public accessData: AccessDataService,
    public config: ConfigService
  ) { }

  ngOnInit() {
  }

  ionViewDidEnter() {
    this.accessData.postData({ user_id: this.config.userConnect.id }, 'getProductStatusByUser').subscribe((res: any) => {
      this.config.status = res.status;
    });
  }

  showProfile() {
    this.router.navigate(['members/profile']);
  }


  editSetting() {
    this.router.navigate(['members/settings']);
  }

  myAds() {
    this.router.navigate(['members/my-ads']);
  }

  showMessage() {
    this.router.navigate(['members/messaging']);
  }

  showFavourite() {
    this.router.navigate(['members/favourite']);
  }

  showSearchForm() {
    this.router.navigate(['form']);
  }

}
