import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController, LoadingController, AlertController, MenuController } from '@ionic/angular';
import { AccessDataService } from 'src/app/services/access-data.service';
import { LoadingService } from '../services/loading.service';
import { AlertService } from '../services/alert.service';
import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import {AuthService} from '../services/auth.service';

// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCDfLMNiH4iaxTiTpfJ3N2Np3C8x0ywLzo",
  authDomain: "vongo-2021.firebaseapp.com",
  databaseURL: "https://vongo-2021-default-rtdb.firebaseio.com",
  projectId: "vongo-2021",
  storageBucket: "vongo-2021.appspot.com",
  messagingSenderId: "224016246397",
  appId: "1:224016246397:web:57a8a69cd2159015347314",
  measurementId: "G-66FMD1M24C"
};
@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  windowRef: any;
  public mobileNumber :any;
  name = '';
  phone = '';
  email = '';
  password = '';
  confirmPass = '';
  errors = false;

  disableButton;

  constructor(
    private router: Router,
    public auth:AuthService,
    private toastCtrl: ToastController,
    private alertCtrl: AlertController,
    public accessData: AccessDataService,
    private menuCtrl: MenuController,
    public loader: LoadingService,
    public alert: AlertService
  ) { }

  ngOnInit() {
    this.windowRef = this.auth.windowRef;
    firebase.initializeApp(firebaseConfig);
  }

  ionViewWillEnter() {
    this.menuCtrl.enable(false);
  }

  async ionViewDidEnter() {
    this.windowRef.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('sign-in-button', {
      size: "invisible",
    })
  }

  ionViewDidLoad() {
   this.windowRef.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('sign-in-button', {
    size: "invisible",
  })
  }

  async tryRegister() {
    if (this.name === '') {
      this.presentToast('Your name is required');
    } else if (this.phone === '') {
      this.presentToast('Phone number is required');
    } else if (this.email === '') {
      this.presentToast('Email address is required');
    } else if (this.password === '') {
      this.presentToast('Password is required');
    } else if (this.confirmPass !== this.password) {
      this.presentToast('Password are not the same');
    } else {
      this.disableButton = true;
      this.loader.show();

      return new Promise(resolve => {
        const body = {
          aksi: 'proses_register',
          name: this.name,
          phone: this.phone,
          email: this.email,
          password: this.password,
          password_confirmation: this.confirmPass
        };
        this.accessData.postData(body, 'app_users/store').subscribe((res: any) => {
          this.loader.hide();
          if (res.success === true) {
            this.disableButton = false;
            this.signinWithPhoneNumber();
            //this.router.navigate(['/login']);
          } else {
            this.disableButton = false;
            // console.log(res.msg);
            this.errors = res.errors;
          }
        }, (err) => {
          this.loader.hide();
          this.disableButton = false;
          console.log(err.message);

          this.alert.show('Timeout');
        });
      });
    }
  }

  async presentToast(a) {
    const toast = await this.toastCtrl.create({
      message: a,
      duration: 2000,
      position: 'bottom'
    });
    toast.present();
  }

  signinWithPhoneNumber(){
    var self = this;
    //this.mobileNumber = '+977'+this.mobileNumber;
    var number = '+977'+self.phone;
    const appVerifier = self.windowRef.recaptchaVerifier;
    firebase.auth().signInWithPhoneNumber(number, appVerifier).then((confirmationResult) => {
        //OtpVerification for verify OTP
        self.phone = '';
        self.OtpVerification(confirmationResult);
    }).catch(function (error) {
      console.error("SMS not sent", error);
    });
  }

  async OtpVerification(confirmationResult) {
    var self = this;
    const alert = await self.alertCtrl.create({
      header: 'Enter OTP',
      backdropDismiss: false,
      inputs: [
        {
          name: 'otp',
          type: 'text',
          placeholder: 'Enter your otp',
        }
      ],
      buttons: [{
        text: 'Enter',
        handler: (res) => {
          confirmationResult.confirm(res.otp).then(function (result) {
            self.presentToast('verify OTP Successfully');
            self.router.navigate(['/login']);
          }).catch(function (error) {
            self.presentToast(error);
          });
        }
      }
      ]
    });
    await alert.present();
  }
}
