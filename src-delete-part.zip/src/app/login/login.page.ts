import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {ToastController, MenuController} from '@ionic/angular';
import {AuthService} from '../services/auth.service';
import {LoadingService} from '../services/loading.service';
import {AlertService} from '../services/alert.service';
import {HttpClient} from '@angular/common/http';
import {ConfigService} from '../services/config.service';
import {User} from '../models/user';

@Component({
    selector: 'app-login',
    templateUrl: './login.page.html',
    styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
    email = '';
    phone = '';
    password = '';
    disableButton;

    constructor(
        private toastCtrl: ToastController,
        private menuCtrl: MenuController,
        private loader: LoadingService,
        private auth: AuthService,
        private router: Router,
        public alert: AlertService,
        public http: HttpClient,
        public config: ConfigService
        ) {
        this.auth.getUser().then(user => {
            if (user) {
                this.config.userConnect = new User(user);
                this.router.navigateByUrl('/home');
            }
        });
    }

    ngOnInit() {
    }

    ionViewWillEnter() {
    }

    ionViewDidEnter() {
     this.config.userConnect = null;
     this.disableButton = false;
 }

 async login() {
    if (this.phone === '') {
        this.presentToast('Phone no is required');
    } else if (this.password === '') {
        this.presentToast('Password is required');
    } else {
        this.disableButton = true;
        await this.loader.show();
        this.auth.login({'phone': this.phone, password: this.password}).subscribe(
            async res => {
                console.log(res)
                await this.loader.hide();
                this.disableButton = false;
                if (res) {
                    this.auth.getUser().then(user => {
                        this.config.userConnect = new User(user);
                    });
                    await this.router.navigateByUrl('/home');
                } else {
                    await this.alert.show('Login Failed');
                }
            }, error => {
                console.log(error);
                this.loader.hide();
                this.disableButton = false;
                this.alert.show('Login Failed');
            }
            );
            // data => {
            //     this.alert.show('Logged In');
            // },

            // this.auth.login({email: this.email, password: this.password}).subscribe(async res => {
            //     this.loader.hide();
            //     this.disableButton = false;
            //     if (res) {
            //         this.auth.getUser().then(user => {
            //             this.config.userConnect = new User(user);
            //         });
            //         this.router.navigateByUrl('/home');
            //     } else {
            //         this.alert.show('Login Failed');
            //     }
            // });
        }
    }

    async presentToast(a) {
        const toast = await this.toastCtrl.create({
            message: a,
            duration: 2000,
            position: 'bottom'
        });
        toast.present();
    }
}