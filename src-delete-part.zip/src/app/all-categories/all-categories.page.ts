import {Component, OnInit} from '@angular/core';
import {AccessDataService} from '../services/access-data.service';
import {LoadingService} from '../services/loading.service';
import {NavigationExtras, Router} from '@angular/router';

@Component({
    selector: 'app-all-categories',
    templateUrl: './all-categories.page.html',
    styleUrls: ['./all-categories.page.scss'],
})
export class AllCategoriesPage implements OnInit {

    categories: any[];
    public isSeachBarOpen = false;

    constructor(
        public accessData: AccessDataService,
        public loader: LoadingService,
        private router: Router,
    ) {
    }

    ngOnInit() {
    }

    ionViewDidEnter() {
        this.loader.show();
        this.accessData.postData('', 'getCategories').subscribe((res: any) => {
            this.categories = res;
            this.loader.hide();
        });
    }

    async onSearch(event) {
        const researchVal = {
            name: event.target.value
        };
        const navigationExtras: NavigationExtras = {
            state: {
                research: researchVal
            }
        };
        await this.router.navigate(['list'], navigationExtras);
    }

    async doRefresh(event) {
        this.ngOnInit();
        this.ionViewDidEnter();
        event.target.complete();
    }

}
