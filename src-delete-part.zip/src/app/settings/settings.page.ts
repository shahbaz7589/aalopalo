import {Component, OnInit, Input} from '@angular/core';
import {ModalController} from '@ionic/angular';
import {LanguagePage} from '../modals/language/language.page';
import {LanguageService} from '../services/language.service';
import {ThemeSwitcherService} from '../services/theme-switcher.service';
import {ThemesPage} from '../modals/themes/themes.page';

@Component({
    selector: 'app-settings',
    templateUrl: './settings.page.html',
    styleUrls: ['./settings.page.scss'],
})
export class SettingsPage implements OnInit {

    dataReturned: any;

    constructor(
        public modalController: ModalController,
        public languageService: LanguageService,
        public themeService: ThemeSwitcherService
    ) {
    }

    ngOnInit() {
    }

    async openLanguage() {
        const modal = await this.modalController.create({
            component: LanguagePage
        });
        modal.onDidDismiss().then((dataReturned) => {
            if (dataReturned !== null) {
                this.dataReturned = dataReturned.data;
            }
        });
        return await modal.present();
    }

    async openTheme() {
        const modal = await this.modalController.create({
            component: ThemesPage
        });
        modal.onDidDismiss().then((data) => {
        });
        return await modal.present();
    }

}
