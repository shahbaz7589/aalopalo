import { Component, OnInit, Input } from '@angular/core';
import { AccessDataService } from 'src/app/services/access-data.service';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-item-slide1',
  templateUrl: './item-slide1.component.html',
  styleUrls: ['./item-slide1.component.scss'],
})
export class ItemSlide1Component implements OnInit {

  @Input('data') products;
  @Input('title') title;

  sliderConfig = {
    slidesPerView: 2.5,
    spaceBetween: 0
  };
  constructor(
    public accsData: AccessDataService,
    protected navCtrl: NavController,

  ) { }

  ngOnInit() {}

  showDetail(id){
    this.navCtrl.navigateRoot(['/product-detail/'+id]);
  }
}
