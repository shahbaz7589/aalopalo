import {Component, OnInit, Input} from '@angular/core';
import {NavController} from '@ionic/angular';
import {ConfigService} from 'src/app/services/config.service';

@Component({
    selector: 'app-item2',
    templateUrl: './item2.component.html',
    styleUrls: ['./item2.component.scss'],
})
export class Item2Component implements OnInit {
    @Input('data') products;
    @Input('title') title;

    constructor(
        public config: ConfigService,
        public navCtrl: NavController,
    ) {
    }

    ngOnInit() {
    }

    showDetail(id) {
        this.navCtrl.navigateRoot(['/product-detail/' + id]);
        // this.navCtrl.navigateForward(['product-detail/'+id]);
    }
}
