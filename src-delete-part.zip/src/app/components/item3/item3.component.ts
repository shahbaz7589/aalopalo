import {Component, OnInit, Input} from '@angular/core';
import {NavController} from '@ionic/angular';
import {ConfigService} from 'src/app/services/config.service';

@Component({
    selector: 'app-item3',
    templateUrl: './item3.component.html',
    styleUrls: ['./item3.component.scss'],
})
export class Item3Component implements OnInit {
    @Input('data') category;
    // @Input('title') title;

    sliderConfig = {
        slidesPerView: 2.5,
        spaceBetween: 0
    };

    constructor(
        protected navCtrl: NavController,
        public config: ConfigService
    ) {
    }

    ngOnInit() {
    }

    showDetail(id) {
        this.navCtrl.navigateRoot(['/product-detail/' + id]);
    }

    showProductByCategory(id) {
        this.navCtrl.navigateRoot(['/categories/' + id]);
    }

}
