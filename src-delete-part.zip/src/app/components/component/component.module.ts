import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { ListItemsComponent } from '../list-items/list-items.component';
// import { Item1Component } from '../item1/item1.component';
// import { SlideItemsComponent } from '../slide-items/slide-items.component';
// import { SlidersComponent } from '../sliders/sliders.component';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Block1Component } from '../block1/block1.component';
import { Block2Component } from '../block2/block2.component';
import { Item1Component } from '../item1/item1.component';
import { Block3Component } from '../block3/block3.component';
import { Item2Component } from '../item2/item2.component';
import { Item3Component } from '../item3/item3.component';
import { ItemSlide1Component } from '../item-slide1/item-slide1.component';
import { PipesModule } from 'src/app/pipes/pipes.module';
// import * as tslib_1 from "tslib";
import { TranslateModule } from '@ngx-translate/core';
import { SlidersComponent } from '../sliders/sliders.component';

const PAGES_COMPONENTS = [
  Block1Component,
  Block2Component,
  Block3Component,
  Item1Component,
  Item2Component,
  Item3Component,
  ItemSlide1Component
  // ListItemsComponent,
  // ListItemsComponent,
  // Item1Component,
  // SlideItemsComponent,
  // SlidersComponent
];

@NgModule({
  declarations: [
    Block1Component,
    Block2Component,
    Block3Component,
    Item1Component,
    Item2Component,
    Item3Component,
    ItemSlide1Component,
    SlidersComponent
  ],
  exports: [
    Block1Component,
    Block2Component,
    Block3Component,
    Item1Component,
    Item2Component,
    Item3Component,
    ItemSlide1Component,
    SlidersComponent
  ],
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    PipesModule,
    TranslateModule
  ]
})
export class ComponentModule { }
