import {Component, OnInit} from '@angular/core';
import {IonSlides} from '@ionic/angular';
import {ViewChild} from '@angular/core';
import {ConfigService} from 'src/app/services/config.service';
import {AccessDataService} from 'src/app/services/access-data.service';


@Component({ 
    selector: 'app-sliders',
    templateUrl: './sliders.component.html',
    styleUrls: ['./sliders.component.scss'],
})
export class SlidersComponent implements OnInit {

    slideOptsOne = {
     initialSlide: 0,
     slidesPerView: 1,
     autoplay:true
 };
    ///////////////////////////////
    public slides = [
    {image: 'assets/images/home-banners/banner1.jpg', title: 'Titre 1', sub_title: 'Sous titre 1'},
    {image: 'assets/images/home-banners/banner2.jpg', title: 'Titre 1', sub_title: 'Sous titre 1'},
    {image: 'assets/images/home-banners/banner3.jpg', title: 'Titre 1', sub_title: 'Sous titre 1'},
    ];
    @ViewChild('sliderBanner', {static: true}) autoSlides: IonSlides;

    constructor(
        public config: ConfigService,
        // public accsData: AccessDataService
        ) {
    }

    ngOnInit() {
        // if(empty(this.config.slidBanner)) {
        //   this.accsData.postData("", 'getSetting').subscribe((res: any) => {this.config.setting=res.setting;});
        // }
    }

    ///////// banner slides autoplay function////////////////
    ionViewDidEnter() {
        this.autoSlides.startAutoplay();
    }

    ///////// banner slides previous function///////////////////
    prevSlide() {
        this.autoSlides.slidePrev();
    }

    ///////////// banner slides next function///////////////
    nextSlide() {
        this.autoSlides.slideNext();
    }


}
