import {Component, OnInit, Input} from '@angular/core';
import {AccessDataService} from 'src/app/services/access-data.service';


@Component({
    selector: 'app-slide-items',
    templateUrl: './slide-items.component.html',
    styleUrls: ['./slide-items.component.scss'],
})
export class SlideItemsComponent implements OnInit {

    @Input('data') products;
    @Input('title') title;

    sliderConfig = {
        slidesPerView: 2.5,
        spaceBetween: 0
    };

    constructor(
        public accsData: AccessDataService
    ) {
    }

    ngOnInit() {
    }
}
