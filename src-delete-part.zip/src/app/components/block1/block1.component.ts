import { Component, OnInit, Input } from '@angular/core';
import { AccessDataService } from 'src/app/services/access-data.service';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-block1',
  templateUrl: './block1.component.html',
  styleUrls: ['./block1.component.scss'],
})
export class Block1Component implements OnInit {

  @Input('data') products;
  @Input('title') title;
  
  sliderConfig = {
    slidesPerView: 2.5,
    spaceBetween: 0
  };
  constructor(
    public accsData: AccessDataService,
    public navCtrl: NavController,

  ) { }

  ngOnInit() {}

  showDetail(id){
    this.navCtrl.navigateRoot(['/product-detail/'+id]);
  }

}
