import {Component, OnInit, Input} from '@angular/core';
import {AccessDataService} from 'src/app/services/access-data.service';
import {ConfigService} from 'src/app/services/config.service';

@Component({
    selector: 'app-list-items',
    templateUrl: './list-items.component.html',
    styleUrls: ['./list-items.component.scss'],
})
export class ListItemsComponent implements OnInit {

    @Input('data') category;
    @Input('title') title;

    constructor(
        public accsData: AccessDataService,
        public config: ConfigService
    ) {
    }

    ngOnInit() {
    }

    // routerLink="/product-detail/{{item?.id}}"
}