import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-block3',
  templateUrl: './block3.component.html',
  styleUrls: ['./block3.component.scss'],
})
export class Block3Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
