import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item1',
  templateUrl: './item1.component.html',
  styleUrls: ['./item1.component.scss'],
})
export class Item1Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
