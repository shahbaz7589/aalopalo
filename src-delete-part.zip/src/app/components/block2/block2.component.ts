import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-block2',
  templateUrl: './block2.component.html',
  styleUrls: ['./block2.component.scss'],
})
export class Block2Component implements OnInit {

  constructor() { }

  ngOnInit() {}

}
