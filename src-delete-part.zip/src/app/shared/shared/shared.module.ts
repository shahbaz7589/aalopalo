import {NgModule, ModuleWithProviders} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {PipesModule} from 'src/app/pipes/pipes.module';
import {IonicModule} from '@ionic/angular';
import {SlidersComponent} from 'src/app/components/sliders/sliders.component';
import {TranslateModule} from '@ngx-translate/core';
import {ListItemsComponent} from 'src/app/components/list-items/list-items.component';
import {SlideItemsComponent} from 'src/app/components/slide-items/slide-items.component';
import {AccessDataService} from 'src/app/services/access-data.service';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        PipesModule,
        TranslateModule.forChild()
    ],
    entryComponents: [SlidersComponent, ListItemsComponent, SlideItemsComponent],
    declarations: [SlidersComponent, ListItemsComponent, SlideItemsComponent],

    exports: [
        SlidersComponent,
        ListItemsComponent,
        SlideItemsComponent
    ],
})
export class SharedModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: SharedModule,
            providers: [AccessDataService]
        };
    }
}
