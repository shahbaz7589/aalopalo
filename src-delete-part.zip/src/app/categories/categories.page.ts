import {Component, OnInit} from '@angular/core';
import {AccessDataService} from 'src/app/services/access-data.service';
import {ActivatedRoute} from '@angular/router';
import {NavController} from '@ionic/angular';
import {LoadingService} from '../services/loading.service';

// import { Observable } from 'rxjs';


@Component({
    selector: 'app-categories',
    templateUrl: './categories.page.html',
    styleUrls: ['./categories.page.scss'],
})
export class CategoriesPage implements OnInit {

    id: number;
    categories: any;
    products: any;
    uploadText: any;
    downloadText: any;

    constructor(
        private actRoute: ActivatedRoute,
        public accsData: AccessDataService,
        private navCtrl: NavController,
        public loader: LoadingService
    ) {
    }

    ngOnInit() {
    }

    ionViewDidEnter() {
        this.actRoute.params.subscribe((data: any) => {
            this.id = data.id;
            if (this.id !== 0) {
                this.loadCategoryList().then();
            }
        });
    }

    async loadCategoryList() {
        await this.loader.show();
        return new Promise(resolve => {
            const body = {
                id: this.id,
            }
            this.accsData.postData(body, 'getCategoryById').subscribe((res: any) => {
                for (const data of res) {
                    this.categories = data;
                    break;
                }
                this.loader.hide();
                resolve(true);
            });
        });
    }

    async openProductDetail(a) {
        this.navCtrl.navigateRoot(['/product-detail/' + a]);
    }

}
