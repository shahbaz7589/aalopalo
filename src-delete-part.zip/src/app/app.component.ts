import { GlobalMethods } from './services/global';
import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { Platform, AlertController, IonRouterOutlet,NavController,ToastController } from '@ionic/angular'; 
import {SplashScreen} from '@ionic-native/splash-screen/ngx';
import {StatusBar} from '@ionic-native/status-bar/ngx';
import {Storage} from '@ionic/storage';
import {LanguageService} from './services/language.service';
import {User} from './models/user';
import {ThemeSwitcherService} from './services/theme-switcher.service';
import {AccessDataService} from './services/access-data.service';
import {ConfigService} from './services/config.service';
import {AuthService} from './services/auth.service';
import { Router} from '@angular/router';
import {Location} from '@angular/common';
import { AngularFireDatabase } from '@angular/fire/compat/database';

@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html',
    styleUrls: ['app.component.scss']
})
export class AppComponent implements OnInit {
    public username: string;
    public selectedIndex = 0;
    public appPages = [
    {
        title: 'Home',
        url: '/home',
        icon: 'home',
        auth: false
    },
    {
        title: 'Dashboard',
        url: '/members/dashboard',
        icon: 'speedometer',
        auth: true
    },
    {
        title: 'My Ads',
        url: '/members/my-ads',
        icon: 'megaphone',
        auth: true
    },
    {
        title: 'Message',
        url: '/members/messaging',
        icon: 'mail',
        auth: true
    },
    {
        title: 'My Favourites',
        url: '/members/favourite',
        icon: 'heart',
        auth: true
    },
    {
        title: 'Profile',
        url: '/members/profile',
        icon: 'person',
        auth: true
    },
    {
        title: 'Search',
        url: '/form',
        icon: 'search',
        auth: false
    },{
        title: 'About Us',
        url: '/about-us',
        icon: 'people',
        auth: false
    }
    ];

    public otherPages = [
        /*{
            title: 'Settings',
            url: '/members/settings',
            icon: 'settings'
        },
        {
            title: 'About Us',
            url: '/about-us',
            icon: 'people'
        }*/
        ];
        @ViewChildren(IonRouterOutlet) routerOutlets: QueryList < IonRouterOutlet > ;
        lastTimeBackPress = 0;
        timePeriodToExit = 2000;

        constructor(
            private platform: Platform,
            private splashScreen: SplashScreen,
            private statusBar: StatusBar,
            private storage: Storage,
            public navCtrl: NavController,
            private toastCtrl: ToastController,
            private router: Router,
            public auth: AuthService,
            private languageService: LanguageService,
            private themeService: ThemeSwitcherService,
            public config: ConfigService,
            public accessData: AccessDataService,
            public location: Location,
            private db:AngularFireDatabase,private global:GlobalMethods
            ) {
            this.initializeApp();
        }

        initializeApp() {
            this.initUser();
            this.platform.ready().then(() => {
              this.statusBar.styleLightContent();
              this.splashScreen.hide();
              this.languageService.setInitialAppLanguage();
              this.themeService.setInitAppTheme();
              this.config.dir = this.languageService.getDirection();
              this.backButtonEvent();
          });
          
        }
        

        backButtonEvent() {
            this.platform.backButton.subscribeWithPriority(0, () => {
              this.routerOutlets.forEach(async(outlet: IonRouterOutlet) => {
                if (this.router.url != '/home') {
                    await this.location.back();
                } else if (this.router.url === '/home') {
                  if (new Date().getTime() - this.lastTimeBackPress >= this.timePeriodToExit) {
                    this.lastTimeBackPress = new Date().getTime();
                } else {
                    navigator['app'].exitApp();
                }
            }
        });
          });
        }
        initUser() {
            this.auth.initService()
            console.log("==========INIT USER  ==========")
            this.auth.getUser().then(user => {
                console.log(user);
                if (user){
                    this.config.userConnect = new User(user);
                    // this.router.navigateByUrl('/home');
                    console.log("==========HOME NAVIGATING HERE  ==========")
                } else {
                    // this.router.navigateByUrl('/');
                }
                this.db.object(`unRead/${user.id}`).valueChanges().subscribe((res:any) =>{
                    console.log(`newMsgCheck: ${res.newMsg}`)
                    let condition = res.newMsg
                    if (condition === 'true' || condition === true) {
                      setTimeout(() => {
                        this.global.newMsg = true
                      }, 500);
                    }else{
                        setTimeout(() => {
                            this.global.newMsg = false
                          }, 500);
                    }
                })
                // this.db.database.ref('unRead').child(user.id.toString()).on('value',res =>{
                //     console.log(`newMsgCheck: ${res.val().newMsg}`)
                //     let condition = res.val().newMsg
                //     if (condition === 'true' || condition === true) {
                //       setTimeout(() => {
                //         this.global.newMsg = true
                //       }, 500);
                //     }else{
                //         setTimeout(() => {
                //             this.global.newMsg = false
                //           }, 500);
                //     }
                // })
            });
        }

        ngOnInit() {
            this.languageService.setReadingDirection('ltr');
        }

        login() {
            this.router.navigateByUrl('/login');
        }

        register() {
            this.router.navigateByUrl('/register');
        }

        logout() {
            this.storage.remove('userData');
            this.storage.remove('token');
            this.storage.remove('jwt-token');
            this.router.navigateByUrl('/login');
        }

        checkUser(){            
            this.auth.authenticationState.subscribe(state => {
                console.log("AUH APP",state);
                if (state) {
                    console.log("user is logged in");
                // this.navController.navigateRoot(['menu/tabs/dashboard']);
                // this.splashScreen.hide();
            } else {
                console.log("user is NOT logged in");
                // this.navController.navigateRoot('login');
                // this.splashScreen.hide();
            }
        });
        }

    }
