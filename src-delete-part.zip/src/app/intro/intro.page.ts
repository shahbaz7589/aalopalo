import {Component, OnInit, ViewChild} from '@angular/core';
import {Router} from '@angular/router';
import {MenuController, IonSlides} from '@ionic/angular';
import {AuthService} from '../services/auth.service';
import {SplashScreen} from '@ionic-native/splash-screen/ngx';
import {User} from '../models/user';
import {ConfigService} from '../services/config.service';

@Component({
    selector: 'app-intro',
    templateUrl: './intro.page.html',
    styleUrls: ['./intro.page.scss'],
})
export class IntroPage implements OnInit {

    // @ViewChild('autoSlides', { static: true }) autoSlides: IonSlides;
    @ViewChild(IonSlides) autoSlides: IonSlides;
    visiable = false;

    public slides = [
        {
            image: 'assets/images/intro/slide1.gif',
            title: 'Home Page',
            icon: 'home',
            text: 'With millions of classifieds, find the right opportunity in our categories: car, real estate, job, vacation, fashion, home, video games, ...',
        },
       
        {
            image: 'assets/images/intro/slide2.gif',
            title: 'Dashboard',
            icon: 'desktop-outline',
            text: 'Every day, you will find more than 1 million classified ads from all over the world.'
        },
    ];

    constructor(
        private auth: AuthService,
        private router: Router,
        private menuCtrl: MenuController,
        private splashScreen: SplashScreen,
        public config: ConfigService,
    ) {
    }

    nextSlide() {
        this.autoSlides.slideNext();
    }

    ionViewDidEnter() {
        setTimeout(() => {
            this.splashScreen.hide();
        }, 1500);
        this.autoSlides.startAutoplay();
    }

    ngOnInit() {
    }

    slideChanged() {
        this.autoSlides.getActiveIndex().then(index => {
            this.visiable = index === 1;
        });
    }


    // ngOnInit() {
    //   if (Object.keys(this.auth.getUser()).length == 0) {
    //     this.router.navigateByUrl('/home');
    //   }
    // }
    openLogin() {
        this.auth.getUser().then(user => {
            if (user) {
                this.config.userConnect = new User(user);
                this.router.navigateByUrl('/home');
            } else {
                this.router.navigateByUrl('/login');
            }
        });
        //  this.router.navigate(['/login']);
    }

    ionViewWillEnter() {
        this.menuCtrl.enable(false);
    }
}
