import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';
import { TranslateModule } from '@ngx-translate/core';
import { PipesModule } from 'src/app/pipes/pipes.module';
import { ProductDetailPageRoutingModule } from './product-detail-routing.module';
import { ProductDetailPage } from './product-detail.page';
import { ComponentModule } from '../components/component/component.module';
import {EditProductPageModule} from '../modals/edit-product/edit-product.module';

@NgModule({
  imports: [
    CommonModule,
    // AgmCoreModule.forRoot({
    //   apiKey: 'AIzaSyDaU7ygbhjrOuH3hBHMhrvp_qjB1tAWt8w',
    //   libraries: ['places']
    // }),
    // AgmCoreModule.forRoot({
    //   apiKey: 'AIzaSyDaU7ygbhjrOuH3hBHMhrvp_qjB1tAWt8w',
    // }),
    FormsModule,
    IonicModule,
    ProductDetailPageRoutingModule,
    PipesModule,
    ComponentModule,
    EditProductPageModule,
    TranslateModule.forChild()
  ],
  declarations: [ProductDetailPage]
})
export class ProductDetailPageModule {}
