import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';  
import {AccessDataService} from 'src/app/services/access-data.service';
import {Router, ActivatedRoute} from '@angular/router';
import {ToastController, AlertController, ModalController} from '@ionic/angular';
import {CallNumber} from '@ionic-native/call-number/ngx';
import {ConfigService} from 'src/app/services/config.service';
import {AuthService} from '../services/auth.service';
import {LoadingService} from '../services/loading.service';
import {ImageModalPage} from '../modals/image-modal/image-modal.page';
import {Map, tileLayer, circle} from 'leaflet';
import {EditProductPage} from '../modals/edit-product/edit-product.page';
import {Plugins} from '@capacitor/core';
import { SocialSharing } from '@ionic-native/social-sharing/ngx';

declare var google: any;    
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { NativeGeocoder, NativeGeocoderResult, NativeGeocoderOptions } from '@ionic-native/native-geocoder/ngx';
import { AngularFireDatabase } from '@angular/fire/compat/database';

const {Share} = Plugins;

@Component({
    selector: 'app-product-detail',
    templateUrl: './product-detail.page.html',
    styleUrls: ['./product-detail.page.scss'],
})
export class ProductDetailPage implements OnInit {


  @ViewChild('map', { static: false }) mapElement: ElementRef;
  map: any;
  latitude: number;
  longitude: number;



  // map: Map;
  newMarker: any;
  address: any;
  greenIcon: any;

  id: number;
  isMyProduct = false;

  similarProducts: any = [];
  sliderConfig = {
    slidesPerView: 2.5,
    spaceBetween: 0
};
product: any;
message;
getProductFeatured: any = [];

sliderOpts = {
    zoom: false,
        // slidesPerView: 1.5,
        conteredSlides: true,
        // spaceBetween: 20
    };
    @ViewChild('search', {static: false})
    public searchElementRef: ElementRef;

    constructor(
        private toastCtrl: ToastController,
        public loader: LoadingService,
        public accessData: AccessDataService,
        private actRoute: ActivatedRoute,
        private callNumber: CallNumber,
        public auth: AuthService,
        public alertCtrl: AlertController,
        private router: Router,
        public config: ConfigService,
        private modalController: ModalController,
        private socialSharing: SocialSharing,

        private geolocation: Geolocation,
        private nativeGeocoder: NativeGeocoder,
        private db:AngularFireDatabase

        ) {
    }

/*    async basicShare() {
        await Share.share({
            title: this.product.name,
            text: this.product.name + ': ' + this.product.price,
            url: this.accessData.server + this.product.image,
        });
    }*/


    basicShare() {
        this.socialSharing.share(this.product.name, this.product.name + ': ' + this.product.price, null, this.accessData.server + this.product.image);
    } 


    // The below function is added
/*    loadMap() {
        setTimeout(() => {
            if (this.map) {
                this.map.off();
                this.map.remove();
            }
            this.map = new Map('mapId').setView([this.product.latitude, this.product.longitude], 11);
            tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                {attribution: 'Map <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, © 2020 <a href="https://ikatic.com/">IKATIC</a>'})
                .addTo(this.map); // This line is added to add the Tile Layer to our map
            // this.greenIcon = icon({
            //     iconUrl: 'assets/img/map/leaf-red.png',
            //     shadowUrl: 'assets/img/map/leaf-shadow.png',
            //
            //     iconSize:     [38, 95], // size of the icon
            //     shadowSize:   [50, 64], // size of the shadow
            //     iconAnchor:   [22, 94], // point of the icon which will correspond to marker's location
            //     shadowAnchor: [4, 62],  // the same for the shadow
            //     popupAnchor:  [-3, -76] // point from which the popup should open relative to the iconAnchor
            // });
            // this.newMarker = marker([this.product.latitude, this.product.longitude], {icon: this.greenIcon}).addTo(this.map);
            // this.newMarker = marker([this.product.latitude, this.product.longitude], {draggable: true}).addTo(this.map);
            this.newMarker = circle([this.product.latitude, this.product.longitude], {
                // color: '#ff8100',
                // fillColor: '#ff8100',
                // fillOpacity: 0.5,
                radius: 1000
            }).addTo(this.map);
            this.newMarker.bindPopup(this.product.name);
        }, 50);
    }
    */
    async openPreview(image) {
        const myModal = await this.modalController.create({
            component: ImageModalPage,
            componentProps: {
                img: image
            }
        });
        return await myModal.present();
    }

    ngOnInit() {
        this.actRoute.params.subscribe((data: any) => {
            this.id = data.id;
        });
    }

    async ionViewDidEnter() {
        this.getProductFeatured = this.accessData.getProductFeatured;
        this.product = {};
        await this.loadProduct();
    }

    loadProduct() {
        return new Promise(resolve => {
            const body = {
                id: this.id,
                user_id: this.config.userConnect !== undefined ? this.config.userConnect.id : null
            };
            this.accessData.postData(body, 'getProductById').subscribe((res: any) => {
                this.similarProducts = res.similarProducts;
                this.product = res.product;
                if (this.config.userConnect !== undefined) {
                    if (Number(res.product.user_id) === Number(this.config.userConnect.id)) {
                        this.isMyProduct = true;
                    }
                }
                this.loadGMap();
                // this.loadMap();
                resolve(true);
            });
        });
    }

    async sendMessage() {
        const alert = await this.alertCtrl.create({
            header: 'Message',
            inputs: [
            {
                name: 'message',
                placeholder: 'Enter your message',
                type: 'textarea'
            }
            ],
            buttons: [
            {
                text: 'Cancel',
                role: 'cancel',
                handler: data => {
                    console.log('You Clicked on Cancel');
                }
            },
            {
                text: 'Send',
                handler: data => {
                    return new Promise(async resolve => {
                        const body = {
                            sender_id: this.config.userConnect.id,
                            receiver_id: this.product.user_id,
                            product_id: this.id,
                            msg: data.message,
                        };
                        
                        await this.loader.show();
                        console.log(`Product Details =>${JSON.stringify(this.product)} \n CurrentUser: ${JSON.stringify(this.config.userConnect)}`)
                        const ref = this.db.database.ref(`chat`).child(body.sender_id.toString()).child(body.receiver_id)
                        ref.update({
                            name:this.product.user.name,
                            email:this.product.user.email,
                            img:this.product.product_images? this.product.product_images[0].filename : 'https://www.aalopalo.com/appadmin/public/images/product-default.png',
                            receiver_id:body.receiver_id,
                            sender_id: this.config.userConnect.id,
                            itemName:this.product.name,
                            itemId:this.product.id,
                            created_at: new Date()
                        })
                        ref.child('conversation').push(body).then((res:any) =>{
                            console.log(JSON.stringify(res))
                            
                        this.loader.hide()
                    }).catch(err =>{
                        this.loader.hide()
                        console.log(JSON.stringify(err))
                    })
                    this.db.database.ref(`unRead`).child(body.receiver_id).update({
                        newMsg:true
                    })
                    //for reciever end
                    const _ref = this.db.database.ref(`chat`).child(body.receiver_id).child(body.sender_id.toString())
                        _ref.update({
                            name:this.config.userConnect.name,
                            email:this.config.userConnect.email,
                            img:this.product.product_images ? this.product.product_images[0].filename : 'https://www.aalopalo.com/appadmin/public/images/product-default.png',
                            receiver_id:this.config.userConnect.id,
                            sender_id: body.receiver_id,
                            itemName:this.product.name,
                            itemId:this.product.id,
                            created_at: new Date(),
                            newMsg:true
                        })
                        _ref.child('conversation').push(body).then((res:any) =>{
                            console.log(JSON.stringify(res))
                           
                        this.loader.hide()
                    }).catch(err =>{
                        this.loader.hide()
                        console.log(JSON.stringify(err))
                    })
                    resolve(true)
                    });
                }
            }
            ]
        });
        await alert.present();
    }

    async addToFavourite() {
        await this.loader.show();
        return new Promise(resolve => {
            const body = {
                product_id: this.id,
                user_id: this.config.userConnect.id,
            };
            this.accessData.postData(body, 'products/addOrRemoveFavourite').subscribe((res: any) => {
                this.loader.hide();
                if (res.success) {
                    this.product = res.product;
                    resolve(true);
                } else {
                    console.log('Error');
                }
            }, (err) => {
                console.log('Error: ' + err.message);
            });
        });
    }

    async doRefresh(event) {
        this.ionViewDidEnter();
        event.target.complete();
    }

    launchDialer(nb: string) {
        console.log(nb);
        this.callNumber.callNumber(nb, true)
        .then(res => console.log('Launched dialer!', res))
        .catch(err => console.log('Error launching dialer', err));
    }

    async presentToast(a) {
        const toast = await this.toastCtrl.create({
            message: a,
            duration: 2000,
            position: 'bottom'
        });
        await toast.present();
    }

    addLike() {
        this.loader.show().then();
    }

    async editProduct(data = null) {
        const modal = await this.modalController.create({
            component: EditProductPage,
            componentProps: {product: data},
            animated: true
        });
        return await modal.present();

    }

    loadGMap() {
        let zooms= 15;
        let latLng = new google.maps.LatLng(this.product.latitude, this.product.longitude);
        let mapOptions = {
            center: latLng,
            zoom:zooms,
            minZoom: zooms - 2,
            maxZoom: zooms + 2,
            restriction:{
                latLngBounds:{
                  north: -10,
                  south: -40,
                  east: 100,
                  west: 100,
              },
          },
          mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      this.getAddressFromCoords(this.product.latitude, this.product.longitude);

      this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
/*        this.map.addListener('dragend', () => {
            this.product.latitude = this.map.center.lat();
            this.product.longitude = this.map.center.lng();
            this.getAddressFromCoords(this.map.center.lat(), this.map.center.lng())
        });*/

    }



    getAddressFromCoords(lattitude, longitude) {
        console.log("getAddressFromCoords " + lattitude + " " + longitude);
        let options: NativeGeocoderOptions = {
          useLocale: true,
          maxResults: 5
      };

      this.nativeGeocoder.reverseGeocode(lattitude, longitude, options)
      .then((result: NativeGeocoderResult[]) => {
        this.address = "";
        let responseAddress = [];
        for (let [key, value] of Object.entries(result[0])) {
          if (value.length > 0)
            responseAddress.push(value);

    }
    responseAddress.reverse();
    for (let value of responseAddress) {
      this.address += value + ", ";
  }
  this.address = this.address.slice(0, -2);
  console.log("User Address ",this.address);
})
      .catch((error: any) => {
        this.address = "Address Not Available!";
    });

  }



}
