import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [

  {
    path: 'edit-profile/:id',
    loadChildren: () => import('../edit-profile/edit-profile.module').then( m => m.EditProfilePageModule)
  },
  {
    path: 'discussion',
    loadChildren: () => import('../discussion/discussion.module').then( m => m.DiscussionPageModule)
  },
  {
    path: 'dashboard',
    loadChildren: () => import('../dashboard/dashboard.module').then( m => m.DashboardPageModule)
  },
  {
    path: 'account',
    loadChildren: () => import('../account/account.module').then( m => m.AccountPageModule)
  },
  {
    path: 'products',
    loadChildren: () => import('../products/products.module').then( m => m.ProductsPageModule)
  },
  {
    path: 'language-popover',
    loadChildren: () => import('../language-popover/language-popover.module').then( m => m.LanguagePopoverPageModule)
  },
  {
    path: 'settings',
    loadChildren: () => import('../settings/settings.module').then( m => m.SettingsPageModule)
  },
  {
    path: 'favourite',
    loadChildren: () => import('../favourite/favourite.module').then( m => m.FavouritePageModule)
  },
  {
    path: 'profile',
    loadChildren: () => import('../profile/profile.module').then( m => m.ProfilePageModule)
  },
  {
    path: 'my-ads',
    loadChildren: () => import('../my-ads/my-ads.module').then( m => m.MyAdsPageModule)
  },
  {
    path: 'messaging',
    loadChildren: () => import('../messaging/messaging.module').then( m => m.MessagingPageModule)
  }
  // {
  //   path: 'edit-product/:id',
  //   loadChildren: () => import('../edit-product/edit-product.module').then( m => m.EditProductPageModule)
  // }

  // {
  //   path: 'list/:id',
  //   resolve:{special: DataResolverService},
  //   loadChildren: () => import('../search/list/list.module').then( m => m.ListPageModule)
  // }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MemberRoutingModule { }
