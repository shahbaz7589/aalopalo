import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AllSponsadsPageRoutingModule } from './all-sponsads-routing.module';

import { AllSponsadsPage } from './all-sponsads.page';
import {PipesModule} from '../pipes/pipes.module';
import {TranslateModule} from '@ngx-translate/core';

@NgModule({
  imports: [
  CommonModule,
  FormsModule,
  IonicModule,
  AllSponsadsPageRoutingModule,
  PipesModule,
  TranslateModule.forChild()
  ],
  declarations: [AllSponsadsPage]
})
export class AllSponsadsPageModule {}
