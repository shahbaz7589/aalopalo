import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AllSponsadsPage } from './all-sponsads.page';

const routes: Routes = [
  {
    path: '',
    component: AllSponsadsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AllSponsadsPageRoutingModule {}
