import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AllSponsadsPage } from './all-sponsads.page';

describe('AllSponsadsPage', () => {
  let component: AllSponsadsPage;
  let fixture: ComponentFixture<AllSponsadsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllSponsadsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AllSponsadsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
