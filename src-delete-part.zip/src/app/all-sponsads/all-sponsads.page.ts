import {Component, OnInit} from '@angular/core';
import {AccessDataService} from '../services/access-data.service';
import {LoadingService} from '../services/loading.service';
import {NavigationExtras, Router} from '@angular/router';
import {ConfigService} from '../services/config.service';
import {AlertService} from '../services/alert.service';


@Component({
  selector: 'app-all-sponsads',
  templateUrl: './all-sponsads.page.html',
  styleUrls: ['./all-sponsads.page.scss'],
})
export class AllSponsadsPage implements OnInit {

  getSponsorAd=[];
  offset = 5; 
  limit = 10;
  listmaxcount = 0;

  constructor(
    public accessData: AccessDataService,
    public loader: LoadingService,
    private router: Router,
    public config: ConfigService,
    protected alertctl: AlertService,
    ) {
  }

  ngOnInit() {
  }

  ionViewDidEnter() {
    this.loader.show();
    let requestData = {
      "user_id": this.config.userConnect.id,  
      "start":this.offset ,
      "limit":this.limit ,
    }
    this.accessData.postData(requestData, 'products/getSponsorAd').subscribe((res: any) => {
     console.log(res);
     this.getSponsorAd.push(res.products);
     this.loader.hide();
   });
  }


  loadData(event) {
    setTimeout(() => {
     this.offset = this.offset + 10;
     let requestData = {
      "user_id": this.config.userConnect.id,  
      "start":this.offset ,
      "limit":this.limit ,
    }
    this.accessData.postData(requestData, 'products/getSponsorAd').subscribe((res: any) => {
      this.listmaxcount=res.total_count
      this.getSponsorAd.push(res.products);
    });
    event.target.complete();

    let loopCount=0;
    let allLengths = this.getSponsorAd.forEach(function(element){
      loopCount=loopCount+element.length
    });

    if (loopCount === this.listmaxcount){
      this.alertctl.showWithTitle("All list completed.","max count reached");
      event.target.disabled = true;
    }

  }, 500);
  }



}
