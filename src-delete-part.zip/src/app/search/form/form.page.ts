import {Component, OnInit} from '@angular/core';
import {AccessDataService} from 'src/app/services/access-data.service';
import {Platform} from '@ionic/angular';
import {Router, NavigationExtras} from '@angular/router';

@Component({
    selector: 'app-form',
    templateUrl: './form.page.html',
    styleUrls: ['./form.page.scss'],
})
export class FormPage implements OnInit {

    name: string;
    categoryId: string;
    location: string;
    distance: string;
    categoriesOptions: any = {
        header: 'Select the item category'
    };
    public categories: any;
    public locations: any;
    price: any = {lower: 1, upper: 100000};

    constructor(
        private router: Router,
        private accessData: AccessDataService
    ) {
        this.accessData.getCategory().then((res) => {
            this.categories = res;
        });
        this.accessData.getLocation().then((res) => {
            this.locations = res;
        });
    }

    onChange(ev: any) {
    }

    ngOnInit() {
    }

    openSearch() {
    }

    async tryTrySearch() {
        const search = {
            name: this.name,
            category_id: this.categoryId,
            location_id: this.location,
            priceMin: this.price.lower,
            priceMax: this.price.upper
        };

        /*====== Get search data ======= */
        const navigationExtras: NavigationExtras = {
            state: {
                research: search
            }
        };
        await this.router.navigate(['list'], navigationExtras);
    }
}
