import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccessDataService } from 'src/app/services/access-data.service';
import { ConfigService } from 'src/app/services/config.service';
import { LoadingService } from 'src/app/services/loading.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.page.html',
  styleUrls: ['./list.page.scss'],
})
export class ListPage implements OnInit {

  research: any;
  products: any;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private accessData: AccessDataService,
    public config: ConfigService,
    public loader: LoadingService
  ) {
    this.route.queryParams.subscribe(params => {
      if (this.router.getCurrentNavigation().extras.state) {
        this.research = this.router.getCurrentNavigation().extras.state.research;
        this.trySearch().then();
      }
    });
  }

  async trySearch() {
    await this.loader.show();
    this.accessData.postData(this.research, 'product/findBySearch').subscribe((res: any) => {
      this.loader.hide();
      if (res.success === true) {
        this.products = res.products;
      }
    });
  }

  ngOnInit() {
  }
}
