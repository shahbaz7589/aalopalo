import {ChangeDetectorRef, Component, Input, OnInit, ViewChild} from '@angular/core';  
import {ActionSheetController, AlertController, IonSlides, Platform, ToastController} from '@ionic/angular';
import {Crop, CropOptions} from '@ionic-native/crop/ngx';
import {ImagePicker, ImagePickerOptions} from '@ionic-native/image-picker/ngx';
import {File} from '@ionic-native/file/ngx';
import {AccessDataService} from 'src/app/services/access-data.service';
import {Router} from '@angular/router';
import {Camera, CameraOptions, PictureSourceType} from '@ionic-native/Camera/ngx';
import {Product} from 'src/app/models/product';
import {ConfigService} from 'src/app/services/config.service';
import {FilePath} from '@ionic-native/file-path/ngx';
import {WebView} from '@ionic-native/ionic-webview/ngx';
import {LoadingService} from 'src/app/services/loading.service';
import {Storage} from '@ionic/storage';
import {AuthService} from '../services/auth.service';
import {User} from '../models/user';
import {FileTransfer, FileTransferObject, FileUploadOptions} from '@ionic-native/file-transfer/ngx';

import {Map, tileLayer, Layer, marker, icon, LeafletMouseEvent} from 'leaflet';
declare var google: any;
const STORAGE_KEY = 'my_photos';



import { ElementRef } from '@angular/core';
import { AndroidPermissions } from '@ionic-native/android-permissions/ngx';
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { NativeGeocoder, NativeGeocoderResult, NativeGeocoderOptions } from '@ionic-native/native-geocoder/ngx';

// declare var google;



@Component({
    selector: 'app-products',
    templateUrl: './products.page.html',
    styleUrls: ['./products.page.scss'],
})
export class ProductsPage implements OnInit {


  @ViewChild('map', { static: false }) mapElement: ElementRef;
  map: any;
  address: string;

  latitude: number;
  longitude: number;


  @ViewChild('wizardSlider', {static: true}) slider: IonSlides;
  params: any = {};

  product: Product;
  public user;

  @Input() data: any;
  @Input() events: any;

  path = false;
  prev = true;
  next = true;
  finish = true;

  public categories: any;
  public locations: any;

    // Image Picker
    isLoading = false;
    images = [];

    imagePickerOptions: ImagePickerOptions = {
        maximumImagesCount: 1,
        quality: 50,
    };

    cropOptions: CropOptions = {
        quality: 50
    };

    sliderOptions = {
        allowTouchMove: false,
        pager: false
    };
    currencies: any[] = [
        // {
        //     id: 1,
        //     name: 'Dollar',
        //     symbole: '$'
        // },
        // {
        //     id: 2,
        //     name: 'Euro',
        //     symbole: '€'
        // }
        {
            id: 2,
            name: 'NPR',
            symbole: 'NPR'
        }
        ];

        categoriesOptions: any = {
            header: 'Select the item category'
        };

        adTypes: any[] = [
        {
            id: 1,
            name: 'Buy',
        },
        {
            id: 2,
            name: 'Exchange',
        },
        {
            id: 3,
            name: 'Lost and Found',
        },
        {
            id: 4,
            name: 'Sell',
        }
        ];

        priceTypes: any[] = [
        {
            id: 1,
            name: 'Fixed',
        },
        {
            id: 2,
            name: 'Negotiable',
        },
        {
            id: 3,
            name: 'Price on call',
        },
        {
            id: 4,
            name: 'Auction',
        },
        {
            id: 5,
            name: 'Free',
        }, 
        {
            id: 6,
            name: 'No price',
        }
        ];

        productPhotos = [];
        disableButton;
        // map: Map;

        constructor(
            public accsData: AccessDataService,
            public auth: AuthService,
            private crop: Crop,
            private imagePicker: ImagePicker,
            private file: File,
            private accessData: AccessDataService,
            private toastCtrl: ToastController,
            private router: Router,
            private alertCtrl: AlertController,
            public config: ConfigService,
            private camera: Camera,
            private platform: Platform,
            private ref: ChangeDetectorRef,
            private filePath: FilePath,
            private actionSheetController: ActionSheetController,
            private webview: WebView,
            private toastController: ToastController,
            private storage: Storage,
            public loader: LoadingService,
            private transfer: FileTransfer,


            private geolocation: Geolocation,
            private nativeGeocoder: NativeGeocoder,
            private androidPermissions: AndroidPermissions,
            private locationAccuracy: LocationAccuracy,

            ) {
            this.data = {
                btnPrev: 'Previous',
                btnNext: 'Next',
                btnFinish: 'Save',
            };
            this.product = new Product('');
            this.prev = false;
            this.next = true;
            this.finish = false;
            this.accessData.getCategory().then((res) => {
                this.categories = res;
            });
            this.accessData.getLocation().then((res) => {
                this.locations = res;
            });
        }

        ngOnInit() {
            // this.loadMap();
            this.checkGPSPermission();
            this.loadGMap();
        }

    // The below function is added
    /*loadMap() {
        setTimeout(() => {
            let mark;
            const greenIcon = icon({
                iconUrl: 'assets/img/map/location-marker.png',
                iconSize:     [24, 40], // size of the icon
                iconAnchor:   [24, 40], // point of the icon which will correspond to marker's location
            });
            this.map = new Map('mapId').fitWorld();
            tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: 'Map &copy; 2020, <a href="https://ikatic.omc">Ikatic.com</a>',
                maxZoom: 18,
            }).addTo(this.map);
            this.map.on('locationfound', (e)=>{
                if (e.latlng) {
                    this.product.latitude = e.latlng.lat;
                    this.product.longitude = e.latlng.lng;
                    mark = marker(e.latlng, {icon: greenIcon}).addTo(this.map);
                }
            });
            this.map.locate({setView: true, maxZoom: 16});
            this.map.on('click', (e: LeafletMouseEvent)=> {
                this.product.latitude = e.latlng.lat;
                this.product.longitude = e.latlng.lng;
                mark.setLatLng(e.latlng);
            });
        }, 50);
    }*/

    ionViewDidEnter() {
        this.auth.getUser().then(user => {
            this.config.userConnect = new User(user);
        });
        this.disableButton = false;
    }

    async presentAlert(a) {
        const alert = await this.alertCtrl.create({
            header: a,
            backdropDismiss: false,
            buttons: [
            {
                text: 'Close',
                handler: (blah) => {
                    console.log('Confirm Cancel: blah');
                }
            }, {
                text: 'Try Again',
                handler: () => {
                    this.trySaveProduct();
                }
            }
            ]
        });
        await alert.present();
    }

    prevSlide() {
        this.slider.slidePrev()
    }

    nextSlide() {
        this.slider.slideNext()
    }

    slideHasChanged(index: number): void {
        try {
            this.slider.isBeginning().then(i => {
                this.prev = !i
            });

            this.slider.isEnd().then(i => {
                this.next = !i
                this.finish = i;
            });
        } catch (e) {}
    }

    // tslint:disable-next-line:use-lifecycle-interface
    ngOnChanges(changes: { [propKey: string]: any }) {
        this.data = changes.data.currentValue;
    }

    onEvent(event: string) {
        if (this.events[event]) {
            this.events[event]();
        }
        console.log(event);
    }

    async trySaveProduct() {
        if (this.product.name === '') {
            this.presentToast('Ad title is required');
        } else {
            this.disableButton = true;
            await this.loader.show();
            return new Promise(resolve => {
                const body = {
                    name: this.product.name,
                    price_type: this.product.price_type,
                    price: this.product.price,
                    currency: this.product.currency,
                    phone_number: this.product.phone_number,
                    user_name: this.product.user_name,
                    warranty: this.product.warranty,
                    tags: this.product.tags,
                    youtube_link: this.product.youtube_link,
                    condition: this.product.condition,
                    ad_type: this.product.ad_type,
                    address: this.product.address,

                    /* latitude: this.product.latitude,
                    longitude: this.product.longitude,*/
                    latitude: this.latitude,
                    longitude: this.longitude,

                    description: this.product.description,
                    status: this.product.status,
                    category_id: this.product.category_id,
                    location_id: this.product.location_id,
                    user_id: this.config.userConnect.id,
                };
                console.log(body);
                this.accessData.postData(body, 'products/store').subscribe((res: any) => {
                    this.loader.hide();
                    console.log(res);
                    if (res.success === true) {
                        this.disableButton = true;
                        this.presentToast(res.msg);
                        this.productPhotos.forEach((img) => {
                            this.uploadImage(img.filePath, res.id);
                        });
                        this.router.navigate(['/home']);
                    } else {
                        console.log(res.msg);
                        this.disableButton = false;
                        this.presentToast(res.msg);
                    }
                }, (err) => {
                    this.loader.hide();
                    this.disableButton = false;
                    console.log(err.message);
                    this.presentToast(err.message);
                })
            });
        }
    }

    /*============================================= */
    /*      PROCESS FOR ADDING ARTICLE PHOTOS       */
    /*============================================= */
    async selectImage() {
        const actionSheet = await this.actionSheetController.create({
            header: 'Select Image source',
            buttons: [{
                text: 'Load from Library',
                handler: () => {
                    this.takePicture(this.camera.PictureSourceType.PHOTOLIBRARY);
                }
            },
            {
                text: 'Use Camera',
                handler: () => {
                    this.takePicture(this.camera.PictureSourceType.CAMERA);
                }
            },
            {
                text: 'Cancel',
                role: 'cancel'
            }]
        });
        await actionSheet.present();
    }

    loadStoredImages() {
        this.storage.get(STORAGE_KEY).then(images => {
            if (images) {
                const arr = JSON.parse(images);
                this.images = [];
                for (const img of arr) {
                    const filePath = this.file.dataDirectory + img;
                    const resPath = this.pathForImage(filePath);
                    this.images.push({name: img, path: resPath, filePath});
                }
            }
        });
    }

    pathForImage(img) {
        if (img === null) {
            return '';
        } else {
            return this.webview.convertFileSrc(img);
        }
    }

    takePicture(sourceType: PictureSourceType) {
        const options: CameraOptions = {
            quality: 100,
            sourceType,
            saveToPhotoAlbum: false,
            correctOrientation: true
        };

        this.camera.getPicture(options).then(imagePath => {
            if (this.platform.is('android') && sourceType === this.camera.PictureSourceType.PHOTOLIBRARY) {
                this.filePath.resolveNativePath(imagePath)
                .then(filePath => {
                    const correctPath = filePath.substr(0, filePath.lastIndexOf('/') + 1);
                    const currentName = imagePath.substring(imagePath.lastIndexOf('/') + 1, imagePath.lastIndexOf('?'));
                    this.copyFileToLocalDir(correctPath, currentName, this.createFileName());
                });
            } else {
                const currentName = imagePath.substr(imagePath.lastIndexOf('/') + 1);
                const correctPath = imagePath.substr(0, imagePath.lastIndexOf('/') + 1);
                this.copyFileToLocalDir(correctPath, currentName, this.createFileName());
            }
        });
    }

    createFileName() {
        const d = new Date(),
        n = d.getTime();
        return n + '.jpg';
    }

    copyFileToLocalDir(namePath, currentName, newFileName) {
        this.file.copyFile(namePath, currentName, this.file.dataDirectory, newFileName).then(success => {
            const filePath = this.file.dataDirectory + newFileName;
            this.updateStoredImages(newFileName);
        }, error => {
            this.presentToast('Error while storing file.').then();
        });
    }

    updateStoredImages(name) {
        this.storage.get(STORAGE_KEY).then(images => {
            const arr = JSON.parse(images);
            if (!arr) {
                const newImages = [name];
                this.storage.set(STORAGE_KEY, JSON.stringify(newImages)).then();
            } else {
                arr.push(name);
                this.storage.set(STORAGE_KEY, JSON.stringify(arr)).then();
            }

            const filePath = this.file.dataDirectory + name;
            const resPath = this.pathForImage(filePath);

            const newEntry = {
                name,
                path: resPath,
                filePath
            };
            this.images = [newEntry, ...this.images];
            this.productPhotos.push(newEntry);
        this.ref.detectChanges(); // trigger change detection cycle
    });
    }

    deleteImage(imgEntry, position) {
        this.images.splice(position, 1);
        this.storage.get(STORAGE_KEY).then(images => {
            const arr = JSON.parse(images);
            const filtered = arr.filter(name => name !== imgEntry.name);
            this.storage.set(STORAGE_KEY, JSON.stringify(filtered));

            const correctPath = imgEntry.filePath.substr(0, imgEntry.filePath.lastIndexOf('/') + 1);

            this.file.removeFile(correctPath, imgEntry.name).then(res => {
                this.presentToast('File removed.');
            });
        });
    }

    /*=========================================*/
    /*          START UPLOAD IMAGE             */
    /*=========================================*/
    async uploadImage(img, id) {
        console.log("UPLOADING IMAGE HERE =========>");
        const fileName = this.createFileName();

    // create file transfer object
    const fileTransfer: FileTransferObject = this.transfer.create();

        // option transfer
        const options: FileUploadOptions = {
            fileKey: 'photo',
            fileName: Math.floor(Math.random() * (999999 - 100000)) + 100000 + '-' + fileName,
            chunkedMode: false,
            httpMethod: 'post',
            mimeType: 'image/jpeg',
            headers: {}
        };

        // file transfer action
        console.log(this.config.serverUrl + 'products/' + id + '/upload-image');
        fileTransfer.upload(img, this.config.serverUrl + 'products/' + id + '/upload-image', options)
        .then(() => {
            this.presentToast('Profile photo has been updated');
            console.log('Profile photo has been updated');
        }, () => {
            this.presentToast('A problem occurred while updating the photo');
            console.log('A problem occurred while updating the photo');
        });
    }

    async presentToast(text) {
        const toast = await this.toastController.create({
            message: text,
            position: 'bottom',
            duration: 3000
        });
        toast.present();
    }

    updateSearch(){
        let input = document.getElementById('googlePlaces').getElementsByTagName('input')[0];
        let autocomplete = new google.maps.places.Autocomplete(input, {types: ['geocode']});
        google.maps.event.addListener(autocomplete, 'place_changed', () => {
          // retrieve the place object for your use
          let place = autocomplete.getPlace();
          console.log(place);
          console.log(this.product);
          
      });
    }


    loadGMap() {
        this.geolocation.getCurrentPosition().then((resp) => {
          this.latitude = resp.coords.latitude;
          this.longitude = resp.coords.longitude;

          let latLng = new google.maps.LatLng(resp.coords.latitude, resp.coords.longitude);
          let mapOptions = {
            center: latLng,
            zoom: 15,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        }

        this.getAddressFromCoords(resp.coords.latitude, resp.coords.longitude);

        this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);

        this.map.addListener('dragend', () => {

            this.latitude = this.map.center.lat();
            this.longitude = this.map.center.lng();

            this.getAddressFromCoords(this.map.center.lat(), this.map.center.lng())
        });

    }).catch((error) => {
      console.log('Error getting location', error);
  });
}

getAddressFromCoords(lattitude, longitude) {
    console.log("getAddressFromCoords " + lattitude + " " + longitude);
    let options: NativeGeocoderOptions = {
      useLocale: true,
      maxResults: 5
  };

  this.nativeGeocoder.reverseGeocode(lattitude, longitude, options)
  .then((result: NativeGeocoderResult[]) => {
    this.address = "";
    let responseAddress = [];
    for (let [key, value] of Object.entries(result[0])) {
      if (value.length > 0)
        responseAddress.push(value);

}
responseAddress.reverse();
for (let value of responseAddress) {
  this.address += value + ", ";
}
this.address = this.address.slice(0, -2);
this.product.address = this.address.slice(0, -2);
})
  .catch((error: any) => {
    this.address = "Address Not Available!";
});

}

//Check if application having GPS access permission  
checkGPSPermission() {
    this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION).then(
      result => {
        if (result.hasPermission){
          //If having permission show 'Turn On GPS' dialogue
          this.askToTurnOnGPS();
      } else {
          //If not having permission ask for permission
          this.requestGPSPermission();
      }
  },
  err => {
        // alert(err);
    }
    );
}

requestGPSPermission() {
    this.locationAccuracy.canRequest().then((canRequest: boolean) => {
      if (canRequest) {
        console.log("4");
    } else {
        //Show 'GPS Permission Request' dialogue
        this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.ACCESS_COARSE_LOCATION)
        .then(
          () => {
              // call method to turn on GPS
              this.askToTurnOnGPS();
          },
          error => {
              //Show alert if user click on 'No Thanks'
              alert('requestPermission Error requesting location permissions ' + error)
          }
          );
    }
});
}

askToTurnOnGPS() {
    this.locationAccuracy.request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
      () => {
        // When GPS Turned ON call method to get Accurate location coordinates
    },
    error => alert('Error requesting location permissions ' + JSON.stringify(error))
    );
}



}
