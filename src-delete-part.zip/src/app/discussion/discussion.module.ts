import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { DiscussionPageRoutingModule } from './discussion-routing.module';
import {AutosizeModule} from 'ngx-autosize';
import { DiscussionPage } from './discussion.page';
import {PipesModule} from '../pipes/pipes.module';
import {TranslateModule} from '@ngx-translate/core';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    DiscussionPageRoutingModule,
    AutosizeModule,
    PipesModule,
    TranslateModule.forChild()
  ],
  declarations: [DiscussionPage]
})
export class DiscussionPageModule {}
