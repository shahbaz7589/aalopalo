import { ConfigService } from 'src/app/services/config.service';
import { GlobalMethods } from './../services/global';
import { Component, OnInit, ViewChild } from '@angular/core';
import { IonContent, ActionSheetController, ToastController, LoadingController } from '@ionic/angular';
import { AccessDataService } from 'src/app/services/access-data.service';
import { ActivatedRoute, Router, UrlSegment } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { User } from '../models/user';
import { LoadingService } from '../services/loading.service';
import { Camera, CameraOptions, PictureSourceType } from '@ionic-native/Camera/ngx';
import { finalize } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { AngularFireDatabase } from '@angular/fire/compat/database';

@Component({
    selector: 'app-discussion',
    templateUrl: './discussion.page.html',
    styleUrls: ['./discussion.page.scss'],
})

export class DiscussionPage implements OnInit {
    discussion: any = {};
    messages: any = [];
    limit = 13;
    start = 0;
    user: any = {}
    id: number;
    newMsg = '';
    imgBase64 = '';
    productdetails: any;

    receiver_id: string
    sender_id: string
    passedData: any = {}

    @ViewChild('content', { static: false }) content: IonContent;

    constructor(
        private toastCtrl: ToastController,
        private camera: Camera,
        private http: HttpClient,
        private loadingController: LoadingController,
        private actionSheetController: ActionSheetController,
        public accessData: AccessDataService,
        private auth: AuthService,
        private loader: LoadingService,
        private actRoute: ActivatedRoute,
        private db: AngularFireDatabase,
        private router: Router,
        public global: GlobalMethods,
        private config: ConfigService
    ) {
    }

    ngOnInit() {
        // this.actRoute.params.subscribe((data: any) => {
        // this.receiver_id = data.id.receiver_id;
        // this.sender_id = data.id.sender_id

        this.auth.getUser().then(async user => {
            this.user = new User(user)
            console.log('User inside:' + JSON.stringify(user))

        });
        this.passedData = this.router.getCurrentNavigation().extras.queryParams.data
        console.log('Router data:' + JSON.stringify(this.router.getCurrentNavigation().extras.queryParams.data))


        // });
        // setTimeout(() => {
        //     this.content.scrollToBottom(500);
        // });
    }

    ionViewWillEnter() {
        // console.log('User outside:'+JSON.stringify(this.user))

        this.start = 0;
        this.messages = [];
        this.loadMessages()
    }
    ngAfterViewInit(): void {

        this.goDown()
    
      }
    ngOnDestroy(): void {
        //Called once, before the instance is destroyed.
        //Add 'implements OnDestroy' to the class.
        this.db.database.ref('chat').child(this.passedData.sender_id).child(this.passedData.receiver_id).update({
            newMsg: false
        })
        this.db.database.ref(`unRead`).child(this.passedData.sender_id).update({
            newMsg: false
        })
    }

    async loadMessages() {
        return new Promise(resolve => {
            // const body = {
            //     // discussion_id: this.id,
            //     product_id: this.id,
            //     start: this.start,
            //     sender_id: this.user.id,
            //     limit: this.limit
            // };
            // this.loader.loading()
            this.global.presentLoading('').then(() => {
                this.db.list(`chat/${this.passedData.sender_id}/${this.passedData.receiver_id}/conversation`).valueChanges().subscribe((chat: any) => {
                    this.messages = chat
                    console.log(`chat => ${JSON.stringify(this.messages)}`)
                    // this.loader.hide()
                    if (chat) {
                        this.goDown()
                    }
                    // this.scrollToBottomOnInit();
                    resolve(true);
                    this.global.hideLoading()
                }, err => {
                    this.global.hideLoading().then(() => {
                        this.toastCtrl.create({
                            message: err.message,
                            duration: 2000
                        })
                        console.log(JSON.stringify(err))
                    })

                    // this.loader.hide()
                });
            })

        });
    }
    goDown() {

        setTimeout(() => {
            this.content.scrollToBottom(300)
        }, 1000);
    }
    sendMessage() {
        return new Promise(async resolve => {
            // const body = {
            //     // discussion_id: this.id,
            //     product_id: ,
            //     sender_id: this.user.id,
            //     receiver_id: this.productdetails.receiver_id,
            //     // receiver_id: this.discussion.product.user_id,
            //     msg: this.newMsg,
            // };
            const body = {
                sender_id: this.user.id,
                receiver_id: this.passedData.receiver_id,
                product_id: this.passedData.itemId,
                msg: this.newMsg,
            };

            // await this.loader.show();

            const ref = this.db.database.ref(`chat`).child(this.passedData.sender_id.toString()).child(this.passedData.receiver_id)
            ref.child('conversation').push(body).then((res: any) => {
                console.log(JSON.stringify(res))

                // this.loader.hide()

            }).catch(err => {
                // this.loader.hide()
                console.log(JSON.stringify(err))
            })
            this.db.database.ref(`unRead`).child(this.passedData.receiver_id).update({
                newMsg: true
            })
            //for reciever end
            const _ref = this.db.database.ref(`chat`).child(this.passedData.receiver_id).child(this.passedData.sender_id.toString())
            
            console.log(`currentUSer: ${JSON.stringify(this.user)}`)
            const obj:any = {
                name: this.user.name,
                email: this.user.email,
                img: this.passedData.img,
                receiver_id: this.passedData.sender_id,
                sender_id: this.passedData.receiver_id,
                itemName: this.passedData.itemName,
                itemId: this.passedData.itemId,
                newMsg: true,
                created_at: new Date()
            }
            console.log('obj:'+JSON.stringify(obj))

            _ref.update(obj)
            _ref.child('conversation').push(body).then((res: any) => {
                console.log(JSON.stringify(res))

                // this.loader.hide()
                this.newMsg = ''
            }).catch(err => {
                // this.loader.hide()
                console.log(JSON.stringify(err))
            })
        });
    }


    sendIMGMessage() {
        // return new Promise(async resolve => {
        console.log(`Sending img message`)
        const body = {
            // discussion_id: this.id,
            product_id: this.id,
            sender_id: this.passedData.id,
            receiver_id: this.passedData.receiver_id,
            // receiver_id: this.discussion.product.user_id,
            photo: this.imgBase64,
        };


        const ref = this.db.database.ref(`chat`).child(this.passedData.sender_id.toString()).child(this.passedData.receiver_id)
        ref.child('conversation').push(body).then((res: any) => {
            console.log(JSON.stringify(res))

            // this.loader.hide()

        }).catch(err => {
            // this.loader.hide()
            console.log(JSON.stringify(err))
        })

        //for reciever end
        const _ref = this.db.database.ref(`chat`).child(this.passedData.receiver_id).child(this.passedData.sender_id.toString())
        _ref.update({
            newMsg: true
        })
        _ref.child('conversation').push(body).then((res: any) => {
            console.log(JSON.stringify(res))

            // this.loader.hide()
            this.newMsg = ''
            // resolve(true)
        }).catch(err => {
            // this.loader.hide()
            console.log(JSON.stringify(err))
        })
        // await this.loader.show();
        // this.accessData.postData(body, 'message/sendMassage').subscribe((res: any) => {
        //     this.loader.hide();
        //     console.log(res)
        //     if (res.success === true) {
        //         this.messages.push(res.msg_sent);
        //         this.newMsg = '';
        //         this.scrollToBottomOnInit();
        //     } else {
        //         console.log(res.msg);
        //     }
        // }, (err) => {
        //     this.loader.hide();
        //     console.log(err.message);
        // });
        // });
    }

    scrollToBottomOnInit() {
        setTimeout(() => {
            this.content.scrollToBottom(300);
        });
    }


    async selectImage() {
        const actionSheet = await this.actionSheetController.create({
            header: "Select Image source",
            buttons: [{
                text: 'Load from Library',
                handler: () => {
                    this.takePicture(this.camera.PictureSourceType.PHOTOLIBRARY);
                }
            },
            {
                text: 'Use Camera',
                handler: () => {
                    this.takePicture(this.camera.PictureSourceType.CAMERA);
                }
            },
            {
                text: 'Cancel',
                role: 'cancel'
            }
            ]
        });
        await actionSheet.present();
    }



    // 

    takePicture(sourceType: any) {
        //id field for identify field variable name
        const options: CameraOptions = {
            quality: 70,
            //destinationType: this.camera.DestinationType.FILE_URI,     
            // encodingType: this.camera.EncodingType.JPEG,
            // mediaType: this.camera.MediaType.PICTURE,
            // sourceType: sourceType,
            sourceType: sourceType,
            correctOrientation: true,
            saveToPhotoAlbum: false,
            destinationType: this.camera.DestinationType.DATA_URL,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
        }
        this.camera.getPicture(options).then((imageData) => {
            // imageData is either a base64 encoded string or a file URI
            // If it's base64 (DATA_URL):
            this.imgBase64 = 'data:image/jpeg;base64,' + imageData;
            // console.log("base64Image", base64Image);
            this.presentToast("Image Added Successfully").then(() => {
                this.sendIMGMessage();
            })

        }, (err: any) => {
            // Handle error
            //   this.presentToast("Image Added Failed!");
            console.log("Error Occured while capture image", err);
        });
    }



    async presentToast(a) {
        const toast = await this.toastCtrl.create({
            message: a,
            duration: 2000,
            position: 'bottom'
        });
        toast.present();
    }



}