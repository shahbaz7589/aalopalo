import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MyAdsPageRoutingModule } from './my-ads-routing.module';
import { PipesModule } from 'src/app/pipes/pipes.module';

import { MyAdsPage } from './my-ads.page';
import {TranslateModule} from '@ngx-translate/core';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PipesModule,
    TranslateModule.forChild(),
    MyAdsPageRoutingModule
  ],
  declarations: [MyAdsPage]
})
export class MyAdsPageModule {}
