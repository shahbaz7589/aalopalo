import {Component, OnInit} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {NavController} from '@ionic/angular';
import {ConfigService} from 'src/app/services/config.service';
import {LoadingService} from 'src/app/services/loading.service';
import {AuthService} from '../services/auth.service';
import {AccessDataService} from '../services/access-data.service';

@Component({
    selector: 'app-my-ads',
    templateUrl: './my-ads.page.html',
    styleUrls: ['./my-ads.page.scss'],
})
export class MyAdsPage implements OnInit {
    public profile;
    public products: Array<any>;
    limit = 10;
    start = 0;
    skeletons = [...Array(this.limit).keys()];

    constructor(
        public http: HttpClient,
        public navCtrl: NavController,
        public auth: AuthService,
        public config: ConfigService,
        public loader: LoadingService,
        public accessData: AccessDataService
    ) {
        this.profile = 'post';
    }

    ngOnInit() {
    }

    ionViewDidEnter() {
        this.start = 0;
        this.accessData.postData({user_id: this.config.userConnect.id}, 'getProductStatusByUser').subscribe((res: any) => {
            this.config.status = res.status;
        });

        this.accessData.postData({
            start: this.start,
            limit: this.limit,
            user_id: this.config.userConnect.id
        }, 'getProductByUser').subscribe((res: any) => {
            console.log(res.products);
            this.products = res.products;
        });
    }

    loadData(event: any) {
        this.start += this.limit;
        setTimeout(() => {
            this.accessData.postData({
                start: this.start,
                limit: this.limit,
                user_id: this.config.userConnect.id
            }, 'getProductByUser').subscribe((res: any) => {
                for (const data of res.products) {
                    this.products.push(data);
                }
            });
            event.target.complete();
        }, 500);
    }

    async doRefresh(event: any) {
        await this.loader.show();
        setTimeout(() => {
            this.ionViewDidEnter();
            event.target.complete();
            this.loader.hide();
        }, 500);
    }


}
