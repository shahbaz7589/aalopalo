import { GlobalMethods } from './../services/global';
import { Component, OnInit } from '@angular/core'; 
import { AccessDataService } from '../services/access-data.service';
import { AuthService } from '../services/auth.service';
import { User } from '../models/user';
import { LoadingService } from '../services/loading.service';
import { AngularFireDatabase } from '@angular/fire/compat/database';
import { NavigationExtras, Router } from '@angular/router';

@Component({
  selector: 'app-messaging',
  templateUrl: './messaging.page.html',
  styleUrls: ['./messaging.page.scss'],
})
export class MessagingPage implements OnInit {

  discussions: Array<any> = [];
  limit = 13;
  start = 0;
  user;

  constructor(
    public accessData: AccessDataService,
    private auth: AuthService,
    public loader: LoadingService,
    private db:AngularFireDatabase,
    private router:Router,
    public global:GlobalMethods
    ) { }

  ngOnInit() {
  }
  async initUser() {
    // this.loader.show();
    this.auth.getUser().then(user => {
      this.user = new User(user);
      this.start = 0;
      this.discussions = [];
      this.loadDiscussions();
      // this.loader.hide();
    });
  }
  ionViewDidEnter() {
    this.initUser();
  }

  async loadDiscussions() {
    if (this.user) {
      return new Promise(resolve => {
        const body = {
          user_id: this.user.id,
          start: this.start,
          limit: this.limit
        };
        this.global.presentLoading('').then(() =>{
          this.db.list(`chat/${this.user.id}`).valueChanges().subscribe((chatData:Array<any>) =>{
            this.discussions = chatData
            this.global.hideLoading()
          },err =>{
            this.global.hideLoading()
            this.global.CreateToast(err.message)
          })
        })
        
      });
    }
  }
  deleteChat(data){
    let body = {
      name:data.name,
      email:data.email,
      img:data.img,
      receiver_id:data.receiver_id,
      sender_id: data.sender_id,
      itemName:data.itemName,
      itemId:data.itemId
    }

    const ref = this.db.database.ref('chat').child(data.sender_id)
    ref.orderByChild('sender_id').equalTo(data.sender_id).once('value',creator =>{
      if(creator.exists()){
        this.db.database.ref('chat').child(data.receiver_id).child(body.sender_id).update({
                name: this.user.name,
                email: this.user.email,
                receiver_id: body.sender_id
        }).then(() =>{
          ref.orderByChild(`receiver_id`).equalTo(body.receiver_id).once('child_added',item =>{
            item.ref.remove()
          })
        })
      }else{
        ref.orderByChild(`receiver_id`).equalTo(body.receiver_id).once('child_added',item =>{
          item.ref.remove()
        })
      }
    })
    // this.db.database.ref('chat').child(data.receiver_id).child(body.sender_id).once('child_added',item =>{
    //   item.ref.remove()
    // })
  }

  // deleteChat(data){
  //   let body = {
  //     name:data.name,
  //     email:data.email,
  //     img:data.img,
  //     receiver_id:data.receiver_id,
  //     sender_id: data.sender_id,
  //     itemName:data.itemName,
  //     itemId:data.itemId
  //   }

  //   const ref = this.db.database.ref('chat').child(data.sender_id).orderByChild(`receiver_id`).equalTo(body.receiver_id).once('child_added',item =>{
  //     item.ref.remove()
  //   })
  //   // this.db.database.ref('chat').child(data.receiver_id).child(body.sender_id).once('child_added',item =>{
  //   //   item.ref.remove()
  //   // })
  // }
openChat(data){
  let body = {
    name:data.name,
    email:data.email,
    img:data.img,
    receiver_id:data.receiver_id,
    sender_id: data.sender_id,
    itemName:data.itemName,
    itemId:data.itemId
  }
  this.db.database.ref('chat').child(data.sender_id).child(data.receiver_id).update({
    newMsg : false
  })
  this.db.database.ref(`unRead`).child(data.sender_id).update({
    newMsg:false
})
  let navigationExtras: NavigationExtras = {
    queryParams: {
       data: body
    }
 };
//  console.log(JSON.stringify(body))
 this.router.navigate(["/members/discussion"], navigationExtras);
}
  async doRefresh(event) {
    setTimeout(() => {
      this.ionViewDidEnter();
      event.target.complete();
    }, 500);
  }
}