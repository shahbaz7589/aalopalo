export const environment = {
  production: true,
  firebaseConfig:{
    apiKey: "AIzaSyCDfLMNiH4iaxTiTpfJ3N2Np3C8x0ywLzo",
    authDomain: "vongo-2021.firebaseapp.com",
    databaseURL: "https://vongo-2021-default-rtdb.firebaseio.com",
    projectId: "vongo-2021",
    storageBucket: "vongo-2021.appspot.com",
    messagingSenderId: "224016246397",
    appId: "1:224016246397:web:57a8a69cd2159015347314",
    measurementId: "G-66FMD1M24C"
  }
};
