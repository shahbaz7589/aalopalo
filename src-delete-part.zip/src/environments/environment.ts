// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig:{
    // apiKey: "AIzaSyCDfLMNiH4iaxTiTpfJ3N2Np3C8x0ywLzo",
    // authDomain: "vongo-2021.firebaseapp.com",
    // databaseURL: "https://vongo-2021-default-rtdb.firebaseio.com",
    // projectId: "vongo-2021",
    // storageBucket: "vongo-2021.appspot.com",
    // messagingSenderId: "224016246397",
    // appId: "1:224016246397:web:57a8a69cd2159015347314",
    // measurementId: "G-66FMD1M24C"
    apiKey: "AIzaSyAfScm3P2GRr5zVJy0ESoZMmdktD99qZsk",
  authDomain: "aalopalo-bff69.firebaseapp.com",
  databaseURL: "https://aalopalo-bff69-default-rtdb.firebaseio.com",
  projectId: "aalopalo-bff69",
  storageBucket: "aalopalo-bff69.appspot.com",
  messagingSenderId: "331683346967",
  appId: "1:331683346967:web:d67a06477c1b26cdbc7a52",
  measurementId: "G-6H12RFHREW"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
